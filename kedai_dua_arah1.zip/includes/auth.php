<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /kedai_dua_arah/index.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: /kedai_dua_arah/kasir/index.php');
        exit;
    }
}

function logout() {
    session_destroy();
    header('Location: /kedai_dua_arah/index.php');
    exit;
}
?>
