<?php
// Token validation middleware — include di setiap endpoint yang butuh auth

function getAuthUser($pdo) {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!str_starts_with($authHeader, 'Bearer ')) {
        http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Token tidak ditemukan']);
        exit;
    }

    $token = substr($authHeader, 7);
    $secret = 'kedai_dua_arah_secret_2024';

    // Cek semua user, verifikasi token
    $users = $pdo->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($users as $user) {
        $expected = hash('sha256', $user['id'] . $user['username'] . $user['role'] . $secret . date('Y-m-d'));
        if (hash_equals($expected, $token)) {
            return $user;
        }
    }

    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Token tidak valid atau expired']);
    exit;
}

function requireAdmin($pdo) {
    $user = getAuthUser($pdo);
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success'=>false,'message'=>'Akses ditolak: hanya admin']);
        exit;
    }
    return $user;
}
