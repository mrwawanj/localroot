<?php
$db_path = __DIR__ . '/../data/kedai.db';
$dir = dirname($db_path);
if (!is_dir($dir)) mkdir($dir, 0755, true);

try {
    $pdo = new PDO('sqlite:' . $db_path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('PRAGMA journal_mode=WAL;');

    // Setup tabel
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'kasir'
        );

        CREATE TABLE IF NOT EXISTS menu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            kategori TEXT NOT NULL,
            harga INTEGER NOT NULL,
            stok INTEGER NOT NULL DEFAULT 0,
            foto TEXT DEFAULT '',
            aktif INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS transaksi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kode TEXT UNIQUE NOT NULL,
            total INTEGER NOT NULL,
            bayar INTEGER NOT NULL,
            kembalian INTEGER NOT NULL,
            kasir TEXT NOT NULL,
            metode TEXT NOT NULL DEFAULT 'cash',
            waktu DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS detail_transaksi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transaksi_id INTEGER NOT NULL,
            menu_id INTEGER NOT NULL,
            nama_menu TEXT NOT NULL,
            harga INTEGER NOT NULL,
            qty INTEGER NOT NULL,
            subtotal INTEGER NOT NULL,
            FOREIGN KEY (transaksi_id) REFERENCES transaksi(id)
        );
    ");

    // Migrasi: tambah kolom metode jika belum ada (untuk DB lama)
    $cols = $pdo->query("PRAGMA table_info(transaksi)")->fetchAll(PDO::FETCH_ASSOC);
    $colNames = array_column($cols, 'name');
    if (!in_array('metode', $colNames)) {
        $pdo->exec("ALTER TABLE transaksi ADD COLUMN metode TEXT NOT NULL DEFAULT 'cash'");
    }

    // Seed default users jika kosong
    $count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("
            INSERT INTO users (username, password, role) VALUES
            ('admin', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'admin'),
            ('kasir', '" . password_hash('kasir123', PASSWORD_DEFAULT) . "', 'kasir');
        ");
    }

    // Seed menu jika kosong
    $menuCount = $pdo->query("SELECT COUNT(*) FROM menu")->fetchColumn();
    if ($menuCount == 0) {
        $pdo->exec("
            INSERT INTO menu (nama, kategori, harga, stok, foto) VALUES
            ('Indomie Goreng', 'Makanan', 12000, 50, ''),
            ('Indomie Goreng + Telur', 'Makanan', 15000, 50, ''),
            ('Indomie Kuah', 'Makanan', 12000, 50, ''),
            ('Indomie Kuah + Telur', 'Makanan', 15000, 50, ''),
            ('Indomie Goreng Spesial', 'Makanan', 18000, 30, ''),
            ('Nasi Goreng', 'Makanan', 15000, 30, ''),
            ('Kopi Hitam', 'Minuman', 5000, 100, ''),
            ('Kopi Susu', 'Minuman', 8000, 100, ''),
            ('Es Cappuccino', 'Minuman', 12000, 100, ''),
            ('Es Teh Manis', 'Minuman', 5000, 100, ''),
            ('Teh Manis Panas', 'Minuman', 4000, 100, ''),
            ('Es Jeruk', 'Minuman', 7000, 100, ''),
            ('Air Mineral', 'Minuman', 4000, 100, ''),
            ('Gorengan', 'Cemilan', 2000, 50, ''),
            ('Roti Bakar', 'Cemilan', 10000, 20, '');
        ");
    }

} catch (Exception $e) {
    die('<div style="padding:20px;color:red;font-family:sans-serif;">
        <h2>Database Error</h2>
        <p>Pastikan ekstensi PHP SQLite3 aktif di XAMPP (php.ini: extension=pdo_sqlite)</p>
        <code>' . $e->getMessage() . '</code>
    </div>');
}
?>
