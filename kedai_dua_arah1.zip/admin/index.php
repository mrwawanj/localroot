<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

// Stats
$total_menu = $pdo->query("SELECT COUNT(*) FROM menu WHERE aktif=1")->fetchColumn();
$total_trx_hari = $pdo->query("SELECT COUNT(*) FROM transaksi WHERE DATE(waktu)=DATE('now')")->fetchColumn();
$omset_hari = $pdo->query("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(waktu)=DATE('now')")->fetchColumn();
$omset_total = $pdo->query("SELECT COALESCE(SUM(total),0) FROM transaksi")->fetchColumn();

// Menu terlaris
$top_menu = $pdo->query("
    SELECT nama_menu, SUM(qty) as total_qty, SUM(subtotal) as total_omset
    FROM detail_transaksi
    GROUP BY nama_menu
    ORDER BY total_qty DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Transaksi terbaru
$recent_trx = $pdo->query("
    SELECT t.*, COUNT(d.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN detail_transaksi d ON d.transaksi_id = t.id
    GROUP BY t.id
    ORDER BY t.waktu DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

function fmt($n) { return 'Rp ' . number_format($n,0,',','.'); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; background:#0f0700; color:#fff; min-height:100vh; }

/* ===== HEADER ===== */
header {
  background:linear-gradient(135deg,#1f0d00,#3d1f00);
  border-bottom:1px solid rgba(245,200,66,0.2);
  padding:12px 20px;
  display:flex; align-items:center; justify-content:space-between;
  position:sticky; top:0; z-index:100;
}
.brand { display:flex; align-items:center; gap:10px; }
.brand-icon { font-size:22px; }
.brand-name { font-size:17px; font-weight:700; color:#f5c842; }
.brand-sub  { font-size:11px; color:rgba(255,255,255,0.4); }

/* Desktop nav */
.nav { display:flex; gap:4px; }
.nav a {
  color:rgba(255,255,255,0.5); text-decoration:none;
  padding:7px 12px; border-radius:7px; font-size:12px; transition:all 0.2s;
  white-space:nowrap;
}
.nav a:hover,.nav a.active { background:rgba(245,200,66,0.15); color:#f5c842; }
.nav a.logout { color:rgba(255,100,100,0.6); }
.nav a.logout:hover { background:rgba(255,100,100,0.1); color:#ff8080; }

/* Hamburger */
.hamburger {
  display:none; flex-direction:column; gap:5px; cursor:pointer;
  padding:6px; border:1px solid rgba(255,255,255,0.15); border-radius:7px;
  background:none;
}
.hamburger span { display:block; width:20px; height:2px; background:rgba(255,255,255,0.7); border-radius:2px; transition:all 0.3s; }

/* Mobile drawer */
.mobile-nav {
  display:none; position:fixed; inset:0; z-index:200;
}
.mobile-nav.show { display:block; }
.mobile-nav-backdrop {
  position:absolute; inset:0; background:rgba(0,0,0,0.6);
}
.mobile-nav-drawer {
  position:absolute; right:0; top:0; bottom:0;
  width:220px; background:#1f0d00;
  border-left:1px solid rgba(245,200,66,0.2);
  display:flex; flex-direction:column;
  padding:16px 0;
  animation:slideIn 0.25s ease;
}
@keyframes slideIn { from { transform:translateX(100%); } to { transform:translateX(0); } }
.mobile-nav-title {
  font-size:12px; color:rgba(255,255,255,0.3); padding:0 20px 12px;
  text-transform:uppercase; letter-spacing:1px;
  border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:8px;
}
.mobile-nav-drawer a {
  display:block; padding:14px 20px;
  color:rgba(255,255,255,0.7); text-decoration:none;
  font-size:14px; transition:all 0.2s;
  border-left:3px solid transparent;
}
.mobile-nav-drawer a:hover,.mobile-nav-drawer a.active {
  background:rgba(245,200,66,0.08);
  color:#f5c842;
  border-left-color:#f5c842;
}
.mobile-nav-drawer a.logout { color:rgba(255,100,100,0.6); margin-top:auto; }
.mobile-nav-drawer a.logout:hover { background:rgba(255,60,60,0.08); color:#ff8080; border-left-color:#f44; }

/* ===== CONTENT ===== */
.content { padding:20px; max-width:1200px; margin:0 auto; }
.page-title { font-size:20px; font-weight:700; color:#f5c842; margin-bottom:16px; }

/* STATS GRID */
.stats-grid {
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:12px; margin-bottom:20px;
}
.stat-card {
  background:rgba(255,255,255,0.05);
  border:1px solid rgba(255,255,255,0.08);
  border-radius:14px; padding:16px;
}
.stat-label { font-size:10px; color:rgba(255,255,255,0.4); text-transform:uppercase; letter-spacing:1px; margin-bottom:6px; }
.stat-value { font-size:22px; font-weight:700; color:#f5c842; }
.stat-sub { font-size:10px; color:rgba(255,255,255,0.3); margin-top:3px; }

/* SECTIONS */
.two-col { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
.section-title {
  font-size:14px; font-weight:600; color:rgba(255,255,255,0.7);
  margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;
}
.btn-sm {
  padding:5px 12px; border-radius:6px; font-size:11px; font-weight:600;
  cursor:pointer; border:none; text-decoration:none; display:inline-block;
}
.btn-primary { background:#f5c842; color:#1a0a00; }

.card-box {
  background:rgba(255,255,255,0.03);
  border:1px solid rgba(255,255,255,0.07);
  border-radius:12px; overflow:hidden;
}
table { width:100%; border-collapse:collapse; font-size:12px; }
th {
  text-align:left; padding:9px 10px;
  border-bottom:1px solid rgba(255,255,255,0.1);
  color:rgba(255,255,255,0.4); font-weight:600; font-size:10px;
  text-transform:uppercase; letter-spacing:0.5px;
}
td { padding:9px 10px; border-bottom:1px solid rgba(255,255,255,0.05); color:rgba(255,255,255,0.8); }
tr:hover td { background:rgba(255,255,255,0.03); }
.badge { display:inline-block; padding:2px 7px; border-radius:4px; font-size:10px; font-weight:600; }
.badge-green { background:rgba(100,200,100,0.15); color:#80ff80; }
.badge-yellow { background:rgba(245,200,66,0.15); color:#f5c842; }

/* ===== MOBILE ===== */
@media (max-width:640px) {
  .nav { display:none; }
  .hamburger { display:flex; }

  .content { padding:14px; }
  .page-title { font-size:17px; margin-bottom:12px; }

  .stats-grid {
    grid-template-columns:1fr 1fr;
    gap:10px;
  }
  .stat-card { padding:12px; }
  .stat-value { font-size:18px; }

  .two-col { grid-template-columns:1fr; gap:16px; }

  /* Tabel jadi card di mobile */
  .card-box { border-radius:10px; }
  .mobile-cards thead { display:none; }
  .mobile-cards tr {
    display:flex; flex-direction:column;
    padding:10px 12px; gap:4px;
    border-bottom:1px solid rgba(255,255,255,0.07);
  }
  .mobile-cards tr:hover { background:rgba(255,255,255,0.03); }
  .mobile-cards td {
    display:flex; justify-content:space-between; align-items:center;
    padding:0; border:none; font-size:12px;
  }
  .mobile-cards td::before {
    content:attr(data-label);
    font-size:10px; color:rgba(255,255,255,0.3);
    text-transform:uppercase; letter-spacing:0.5px;
    flex-shrink:0; margin-right:8px;
  }
  .mobile-cards td:first-child { font-weight:600; font-size:13px; }
  .mobile-cards td:first-child::before { display:none; }
}

@media (min-width:641px) {
  .stats-grid { grid-template-columns:repeat(4,1fr); }
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <span class="brand-icon">☕</span>
    <div>
      <div class="brand-name">Kedai Dua Arah</div>
      <div class="brand-sub">Panel Admin</div>
    </div>
  </div>
  <nav class="nav">
    <a href="index.php" class="active">📊 Dashboard</a>
    <a href="menu.php">🍜 Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">Keluar</a>
  </nav>
  <button class="hamburger" onclick="toggleNav()" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</header>

<!-- Mobile nav drawer -->
<div class="mobile-nav" id="mobileNav">
  <div class="mobile-nav-backdrop" onclick="closeNav()"></div>
  <div class="mobile-nav-drawer">
    <div class="mobile-nav-title">Menu Admin</div>
    <a href="index.php" class="active">📊 Dashboard</a>
    <a href="menu.php">🍜 Kelola Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">🚪 Keluar</a>
  </div>
</div>

<div class="content">
  <div class="page-title">📊 Dashboard</div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-label">Transaksi Hari Ini</div>
      <div class="stat-value"><?= $total_trx_hari ?></div>
      <div class="stat-sub">transaksi</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Omset Hari Ini</div>
      <div class="stat-value" style="font-size:17px"><?= fmt($omset_hari) ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Omset</div>
      <div class="stat-value" style="font-size:17px"><?= fmt($omset_total) ?></div>
      <div class="stat-sub">semua waktu</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Menu Aktif</div>
      <div class="stat-value"><?= $total_menu ?></div>
      <div class="stat-sub">item</div>
    </div>
  </div>

  <div class="two-col">
    <!-- MENU TERLARIS -->
    <div>
      <div class="section-title">🏆 Menu Terlaris</div>
      <div class="card-box">
        <table class="mobile-cards">
          <thead>
            <tr><th>#</th><th>Menu</th><th>Terjual</th><th>Omset</th></tr>
          </thead>
          <tbody>
            <?php foreach($top_menu as $i=>$m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td data-label="Menu"><?= htmlspecialchars($m['nama_menu']) ?></td>
              <td data-label="Terjual"><span class="badge badge-yellow"><?= $m['total_qty'] ?>x</span></td>
              <td data-label="Omset"><?= fmt($m['total_omset']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($top_menu)): ?>
            <tr><td colspan="4" style="text-align:center;color:rgba(255,255,255,0.3);padding:20px">Belum ada data</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TRANSAKSI TERBARU -->
    <div>
      <div class="section-title">
        🧾 Transaksi Terbaru
        <a href="laporan.php" class="btn-sm btn-primary">Lihat Semua</a>
      </div>
      <div class="card-box">
        <table class="mobile-cards">
          <thead>
            <tr><th>Kode</th><th>Total</th><th>Kasir</th><th>Waktu</th></tr>
          </thead>
          <tbody>
            <?php foreach($recent_trx as $t): ?>
            <tr>
              <td style="color:#f5c842;font-size:11px"><?= htmlspecialchars($t['kode']) ?></td>
              <td data-label="Total"><?= fmt($t['total']) ?></td>
              <td data-label="Kasir"><?= htmlspecialchars($t['kasir']) ?></td>
              <td data-label="Waktu" style="font-size:11px;color:rgba(255,255,255,0.4)"><?= date('d/m H:i', strtotime($t['waktu'])) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($recent_trx)): ?>
            <tr><td colspan="4" style="text-align:center;color:rgba(255,255,255,0.3);padding:20px">Belum ada transaksi</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
function toggleNav() { document.getElementById('mobileNav').classList.add('show'); }
function closeNav()  { document.getElementById('mobileNav').classList.remove('show'); }
</script>
</body>
</html>
