<?php
// File debug sementara — hapus setelah selesai testing
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

// Test manual kurangi stok menu id=1 sebanyak 1
if (isset($_GET['test'])) {
    $id  = (int)$_GET['id'];
    $qty = (int)$_GET['qty'];

    $before = $pdo->prepare("SELECT stok FROM menu WHERE id=?");
    $before->execute([$id]);
    $stok_before = $before->fetchColumn();

    $stmt = $pdo->prepare("UPDATE menu SET stok = MAX(0, stok - :qty) WHERE id = :id");
    $stmt->bindValue(':qty', $qty, PDO::PARAM_INT);
    $stmt->bindValue(':id',  $id,  PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->rowCount();

    $after = $pdo->prepare("SELECT stok FROM menu WHERE id=?");
    $after->execute([$id]);
    $stok_after = $after->fetchColumn();

    echo "<pre>ID: $id | Qty dikurangi: $qty | Rows affected: $rows\nStok sebelum: $stok_before\nStok sesudah: $stok_after\n\nSQLite version: " . $pdo->query('SELECT sqlite_version()')->fetchColumn() . "</pre>";
}

$menu = $pdo->query("SELECT id,nama,stok FROM menu ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Debug Stok</title>
<style>body{font-family:monospace;background:#111;color:#0f0;padding:20px}
a{color:#ff0;} table{border-collapse:collapse;width:100%} td,th{border:1px solid #333;padding:8px}
</style></head>
<body>
<h2>Debug Stok Menu</h2>
<p>Test kurangi stok: <a href="?test=1&id=1&qty=1">Menu ID 1, kurangi 1</a></p>

<?php if(isset($_GET['test'])): ?>
<div style="background:#004400;padding:10px;border-radius:4px;margin:10px 0">
  <?php // output sudah di atas ?>
</div>
<?php endif; ?>

<h3>Stok Sekarang:</h3>
<table>
  <tr><th>ID</th><th>Nama</th><th>Stok</th></tr>
  <?php foreach($menu as $m): ?>
  <tr>
    <td><?= $m['id'] ?></td>
    <td><?= htmlspecialchars($m['nama']) ?></td>
    <td style="color:<?= $m['stok']>5?'#0f0':($m['stok']>0?'#ff0':'#f00') ?>"><?= $m['stok'] ?></td>
  </tr>
  <?php endforeach; ?>
</table>

<p style="margin-top:20px;color:#666">Hapus file ini setelah selesai testing: admin/debug_stok.php</p>
</body>
</html>
