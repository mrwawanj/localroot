<?php
// API: PUT /api/stok.php?id=X — update stok menu (admin)
// API: GET /api/stok.php — semua menu + stok (admin)

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, PUT, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/middleware.php';

requireAdmin($pdo);

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if ($method === 'GET') {
    $rows = $pdo->query("SELECT id, nama, kategori, harga, stok, aktif FROM menu ORDER BY kategori, nama")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
        $r['harga'] = (int)$r['harga'];
        $r['stok'] = (int)$r['stok'];
        $r['aktif'] = (int)$r['aktif'];
    }
    echo json_encode(['success'=>true,'data'=>$rows]);

} elseif ($method === 'PUT') {
    if (!$id) { echo json_encode(['success'=>false,'message'=>'ID diperlukan']); exit; }
    $input = json_decode(file_get_contents('php://input'), true);
    $stok = (int)($input['stok'] ?? 0);
    if ($stok < 0) { echo json_encode(['success'=>false,'message'=>'Stok tidak boleh negatif']); exit; }
    $pdo->prepare("UPDATE menu SET stok = ? WHERE id = ?")->execute([$stok, $id]);
    echo json_encode(['success'=>true,'message'=>'Stok berhasil diupdate']);

} else {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Method not allowed']);
}
