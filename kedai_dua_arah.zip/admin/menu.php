<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

$msg = '';
$err = '';

// Upload foto helper
function uploadFoto($file) {
    $upload_dir = __DIR__ . '/../assets/foto/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
    if (!in_array($file['type'], $allowed)) return ['ok'=>false,'msg'=>'Format gambar tidak valid (jpg/png/webp)'];
    if ($file['size'] > 2*1024*1024) return ['ok'=>false,'msg'=>'Ukuran foto max 2MB'];

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $nama_file = uniqid('menu_') . '.' . strtolower($ext);
    if (!move_uploaded_file($file['tmp_name'], $upload_dir . $nama_file)) return ['ok'=>false,'msg'=>'Gagal upload foto'];
    return ['ok'=>true,'nama'=>$nama_file];
}

// TAMBAH
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='tambah') {
    $nama     = trim($_POST['nama']??'');
    $kategori = $_POST['kategori']??'Makanan';
    $harga    = (int)($_POST['harga']??0);
    $stok     = (int)($_POST['stok']??0);
    $foto     = '';

    if (!$nama || $harga<=0) {
        $err = 'Nama dan harga wajib diisi.';
    } else {
        if (!empty($_FILES['foto']['name'])) {
            $up = uploadFoto($_FILES['foto']);
            if (!$up['ok']) { $err=$up['msg']; goto done; }
            $foto = $up['nama'];
        }
        $stmt = $pdo->prepare("INSERT INTO menu (nama,kategori,harga,stok,foto) VALUES (?,?,?,?,?)");
        $stmt->execute([$nama,$kategori,$harga,$stok,$foto]);
        $msg = "Menu \"$nama\" berhasil ditambahkan.";
    }
}

// EDIT
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='edit') {
    $id       = (int)($_POST['id']??0);
    $nama     = trim($_POST['nama']??'');
    $kategori = $_POST['kategori']??'Makanan';
    $harga    = (int)($_POST['harga']??0);
    $stok     = (int)($_POST['stok']??0);

    if (!$id || !$nama || $harga<=0) {
        $err = 'Data tidak valid.';
    } else {
        // cek foto lama
        $old = $pdo->prepare("SELECT foto FROM menu WHERE id=?");
        $old->execute([$id]);
        $old_foto = $old->fetchColumn();
        $foto = $old_foto;

        if (!empty($_FILES['foto']['name'])) {
            $up = uploadFoto($_FILES['foto']);
            if (!$up['ok']) { $err=$up['msg']; goto done; }
            // hapus foto lama
            if ($old_foto && file_exists(__DIR__.'/../assets/foto/'.$old_foto)) {
                @unlink(__DIR__.'/../assets/foto/'.$old_foto);
            }
            $foto = $up['nama'];
        }
        $stmt = $pdo->prepare("UPDATE menu SET nama=?,kategori=?,harga=?,stok=?,foto=? WHERE id=?");
        $stmt->execute([$nama,$kategori,$harga,$stok,$foto,$id]);
        $msg = "Menu berhasil diperbarui.";
    }
}

// HAPUS (nonaktifkan)
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='hapus') {
    $id = (int)($_POST['id']??0);
    if ($id) {
        $pdo->prepare("UPDATE menu SET aktif=0 WHERE id=?")->execute([$id]);
        $msg = "Menu berhasil dihapus.";
    }
}

// RESTORE
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='restore') {
    $id = (int)($_POST['id']??0);
    if ($id) {
        $pdo->prepare("UPDATE menu SET aktif=1 WHERE id=?")->execute([$id]);
        $msg = "Menu berhasil diaktifkan kembali.";
    }
}

done:
$menu_list = $pdo->query("SELECT * FROM menu ORDER BY aktif DESC, kategori, nama")->fetchAll(PDO::FETCH_ASSOC);

function fmt($n) { return 'Rp ' . number_format($n,0,',','.'); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Menu – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; background:#0f0700; color:#fff; min-height:100vh; }
header {
  background: linear-gradient(135deg,#1f0d00,#3d1f00);
  border-bottom: 1px solid rgba(245,200,66,0.2);
  padding: 14px 24px;
  display:flex; align-items:center; justify-content:space-between;
}
.brand-name { font-size:18px; font-weight:700; color:#f5c842; }
.nav { display:flex; gap:4px; }
.nav a { color:rgba(255,255,255,0.5); text-decoration:none; padding:7px 14px; border-radius:7px; font-size:13px; transition:all 0.2s; }
.nav a:hover, .nav a.active { background:rgba(245,200,66,0.15); color:#f5c842; }
.nav a.logout { color:rgba(255,100,100,0.6); }
.nav a.logout:hover { background:rgba(255,100,100,0.1); color:#ff8080; }

.content { padding:24px; max-width:1100px; margin:0 auto; }
.page-title { font-size:20px; font-weight:700; color:#f5c842; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; }

.alert { padding:10px 16px; border-radius:8px; font-size:13px; margin-bottom:16px; }
.alert-success { background:rgba(100,200,100,0.12); border:1px solid rgba(100,200,100,0.3); color:#80ff80; }
.alert-error { background:rgba(255,80,80,0.12); border:1px solid rgba(255,80,80,0.3); color:#ff8080; }

/* MODAL */
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.7); display:none; align-items:center; justify-content:center; z-index:999; }
.modal-overlay.show { display:flex; }
.modal {
  background:#1a0d00;
  border:1px solid rgba(245,200,66,0.2);
  border-radius:16px;
  padding:28px;
  width:420px;
  max-width:95vw;
}
.modal-title { font-size:16px; font-weight:700; color:#f5c842; margin-bottom:20px; }
.form-group { margin-bottom:14px; }
label { display:block; font-size:12px; color:rgba(255,255,255,0.5); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.8px; }
input[type=text],input[type=number],select {
  width:100%; padding:10px 14px;
  background:rgba(255,255,255,0.07);
  border:1px solid rgba(255,255,255,0.12);
  border-radius:8px; color:white; font-size:14px; outline:none;
  transition: border-color 0.2s;
}
input:focus,select:focus { border-color:#f5c842; }
select option { background:#1a0d00; }
input[type=file] {
  width:100%; padding:8px;
  background:rgba(255,255,255,0.05);
  border:1px dashed rgba(255,255,255,0.2);
  border-radius:8px; color:rgba(255,255,255,0.6); font-size:13px; cursor:pointer;
}
.modal-actions { display:flex; gap:10px; margin-top:20px; }
.btn { padding:10px 20px; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; border:none; }
.btn-primary { background:#f5c842; color:#1a0a00; }
.btn-primary:hover { background:#e8a020; }
.btn-secondary { background:rgba(255,255,255,0.08); color:rgba(255,255,255,0.7); }
.btn-secondary:hover { background:rgba(255,255,255,0.12); }
.btn-danger { background:rgba(255,80,80,0.15); color:#ff8080; border:1px solid rgba(255,80,80,0.3); padding:6px 14px; font-size:12px; border-radius:6px; cursor:pointer; }
.btn-danger:hover { background:rgba(255,80,80,0.25); }
.btn-sm-primary { background:#f5c842; color:#1a0a00; border:none; padding:6px 14px; font-size:12px; border-radius:6px; cursor:pointer; font-weight:600; }

/* TABLE */
.card-box { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:12px; overflow:hidden; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.1); color:rgba(255,255,255,0.4); font-size:11px; text-transform:uppercase; letter-spacing:0.5px; }
td { padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.05); color:rgba(255,255,255,0.8); vertical-align:middle; }
tr:hover td { background:rgba(255,255,255,0.03); }
.menu-foto-thumb { width:44px; height:44px; border-radius:8px; object-fit:cover; }
.foto-placeholder { width:44px; height:44px; border-radius:8px; background:rgba(255,255,255,0.05); display:flex; align-items:center; justify-content:center; font-size:20px; }
.badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; }
.badge-green { background:rgba(100,200,100,0.15); color:#80ff80; }
.badge-red { background:rgba(255,80,80,0.15); color:#ff8080; }
.badge-yellow { background:rgba(245,200,66,0.15); color:#f5c842; }
.inactive td { opacity:0.4; }
.preview-foto { width:80px; height:80px; border-radius:10px; object-fit:cover; display:block; margin-top:8px; }
</style>
</head>
<body>
<header>
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:24px">☕</span>
    <div class="brand-name">Kedai Dua Arah</div>
  </div>
  <nav class="nav">
    <a href="index.php">📊 Dashboard</a>
    <a href="menu.php" class="active">🍜 Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">Keluar</a>
  </nav>
</header>

<div class="content">
  <div class="page-title">
    🍜 Kelola Menu
    <button class="btn btn-primary" onclick="openModal('tambah')">+ Tambah Menu</button>
  </div>

  <?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert alert-error"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="card-box">
    <table>
      <thead>
        <tr>
          <th>Foto</th>
          <th>Nama Menu</th>
          <th>Kategori</th>
          <th>Harga</th>
          <th>Stok</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($menu_list as $m): ?>
        <tr class="<?= $m['aktif']?'':'inactive' ?>">
          <td>
            <?php if($m['foto'] && file_exists('../assets/foto/'.$m['foto'])): ?>
            <img class="menu-foto-thumb" src="/kedai_dua_arah/assets/foto/<?= htmlspecialchars($m['foto']) ?>" alt="">
            <?php else: ?>
            <div class="foto-placeholder"><?= $m['kategori']==='Makanan'?'🍜':($m['kategori']==='Minuman'?'🥤':'🍟') ?></div>
            <?php endif; ?>
          </td>
          <td><strong><?= htmlspecialchars($m['nama']) ?></strong></td>
          <td><?= htmlspecialchars($m['kategori']) ?></td>
          <td><?= fmt($m['harga']) ?></td>
          <td>
            <span class="badge <?= $m['stok']>5?'badge-green':($m['stok']>0?'badge-yellow':'badge-red') ?>">
              <?= $m['stok'] ?>
            </span>
          </td>
          <td>
            <span class="badge <?= $m['aktif']?'badge-green':'badge-red' ?>">
              <?= $m['aktif']?'Aktif':'Nonaktif' ?>
            </span>
          </td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button class="btn-sm-primary" onclick="openEdit(<?= htmlspecialchars(json_encode($m)) ?>)">Edit</button>
              <?php if($m['aktif']): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus menu ini?')">
                <input type="hidden" name="action" value="hapus">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button type="submit" class="btn-danger">Hapus</button>
              </form>
              <?php else: ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="restore">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button type="submit" class="btn-sm-primary" style="background:rgba(100,200,100,0.2);color:#80ff80;border:1px solid rgba(100,200,100,0.3)">Aktifkan</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- MODAL TAMBAH -->
<div class="modal-overlay" id="modalTambah">
  <div class="modal">
    <div class="modal-title">➕ Tambah Menu Baru</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="tambah">
      <div class="form-group">
        <label>Nama Menu</label>
        <input type="text" name="nama" required placeholder="Contoh: Indomie Goreng">
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <select name="kategori">
          <option>Makanan</option>
          <option>Minuman</option>
          <option>Cemilan</option>
        </select>
      </div>
      <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" name="harga" required placeholder="12000" min="0">
      </div>
      <div class="form-group">
        <label>Stok Awal</label>
        <input type="number" name="stok" placeholder="50" min="0" value="50">
      </div>
      <div class="form-group">
        <label>Foto Menu (opsional)</label>
        <input type="file" name="foto" accept="image/*" onchange="previewImg(this,'previewTambah')">
        <img id="previewTambah" class="preview-foto" style="display:none">
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalTambah')">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL EDIT -->
<div class="modal-overlay" id="modalEdit">
  <div class="modal">
    <div class="modal-title">✏️ Edit Menu</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="edit_id">
      <div class="form-group">
        <label>Nama Menu</label>
        <input type="text" name="nama" id="edit_nama" required>
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <select name="kategori" id="edit_kategori">
          <option>Makanan</option>
          <option>Minuman</option>
          <option>Cemilan</option>
        </select>
      </div>
      <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" name="harga" id="edit_harga" required min="0">
      </div>
      <div class="form-group">
        <label>Stok</label>
        <input type="number" name="stok" id="edit_stok" min="0">
      </div>
      <div class="form-group">
        <label>Ganti Foto (opsional)</label>
        <div id="edit_foto_current" style="margin-bottom:8px"></div>
        <input type="file" name="foto" accept="image/*" onchange="previewImg(this,'previewEdit')">
        <img id="previewEdit" class="preview-foto" style="display:none">
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn btn-primary">Update</button>
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalEdit')">Batal</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id) {
  document.getElementById('modal'+id.charAt(0).toUpperCase()+id.slice(1)).classList.add('show');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('show');
}
function openEdit(m) {
  document.getElementById('edit_id').value = m.id;
  document.getElementById('edit_nama').value = m.nama;
  document.getElementById('edit_harga').value = m.harga;
  document.getElementById('edit_stok').value = m.stok;
  document.getElementById('edit_kategori').value = m.kategori;

  const fotoDiv = document.getElementById('edit_foto_current');
  if (m.foto) {
    fotoDiv.innerHTML = `<img src="/kedai_dua_arah/assets/foto/${m.foto}" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">`;
  } else {
    fotoDiv.innerHTML = '<span style="color:rgba(255,255,255,0.3);font-size:12px">Belum ada foto</span>';
  }
  document.getElementById('modalEdit').classList.add('show');
}
function previewImg(input, previewId) {
  const preview = document.getElementById(previewId);
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => { preview.src = e.target.result; preview.style.display='block'; };
    reader.readAsDataURL(input.files[0]);
  }
}
// Tutup modal klik luar
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if(e.target===el) el.classList.remove('show'); });
});
</script>
</body>
</html>
