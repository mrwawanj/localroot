<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

// Stats
$total_menu = $pdo->query("SELECT COUNT(*) FROM menu WHERE aktif=1")->fetchColumn();
$total_trx_hari = $pdo->query("SELECT COUNT(*) FROM transaksi WHERE DATE(waktu)=DATE('now')")->fetchColumn();
$omset_hari = $pdo->query("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(waktu)=DATE('now')")->fetchColumn();
$omset_total = $pdo->query("SELECT COALESCE(SUM(total),0) FROM transaksi")->fetchColumn();

// Menu terlaris
$top_menu = $pdo->query("
    SELECT nama_menu, SUM(qty) as total_qty, SUM(subtotal) as total_omset
    FROM detail_transaksi
    GROUP BY nama_menu
    ORDER BY total_qty DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Transaksi terbaru
$recent_trx = $pdo->query("
    SELECT t.*, COUNT(d.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN detail_transaksi d ON d.transaksi_id = t.id
    GROUP BY t.id
    ORDER BY t.waktu DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

function fmt($n) { return 'Rp ' . number_format($n,0,',','.'); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: 'Segoe UI', sans-serif;
  background: #0f0700;
  color: #fff;
  min-height: 100vh;
}
header {
  background: linear-gradient(135deg, #1f0d00, #3d1f00);
  border-bottom: 1px solid rgba(245,200,66,0.2);
  padding: 14px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.brand { display:flex; align-items:center; gap:10px; }
.brand-icon { font-size:24px; }
.brand-name { font-size:18px; font-weight:700; color:#f5c842; }
.brand-sub { font-size:11px; color:rgba(255,255,255,0.4); }
.nav { display:flex; gap:4px; }
.nav a {
  color: rgba(255,255,255,0.5);
  text-decoration: none;
  padding: 7px 14px;
  border-radius: 7px;
  font-size: 13px;
  transition: all 0.2s;
}
.nav a:hover, .nav a.active {
  background: rgba(245,200,66,0.15);
  color: #f5c842;
}
.nav a.logout { color: rgba(255,100,100,0.6); }
.nav a.logout:hover { background: rgba(255,100,100,0.1); color:#ff8080; }

.content { padding: 24px; max-width: 1200px; margin: 0 auto; }

.page-title {
  font-size: 20px;
  font-weight: 700;
  color: #f5c842;
  margin-bottom: 20px;
}

/* STATS */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px,1fr));
  gap: 16px;
  margin-bottom: 28px;
}
.stat-card {
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 20px;
}
.stat-label { font-size: 11px; color:rgba(255,255,255,0.4); text-transform:uppercase; letter-spacing:1px; margin-bottom:8px; }
.stat-value { font-size: 24px; font-weight: 700; color: #f5c842; }
.stat-sub { font-size: 11px; color:rgba(255,255,255,0.3); margin-top:4px; }

/* TABLE */
.section { margin-bottom: 28px; }
.section-title {
  font-size: 15px;
  font-weight: 600;
  color: rgba(255,255,255,0.7);
  margin-bottom: 14px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.btn-sm {
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  border: none;
  text-decoration: none;
  display: inline-block;
}
.btn-primary { background:#f5c842; color:#1a0a00; }
.btn-primary:hover { background:#e8a020; }

table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
th {
  text-align: left;
  padding: 10px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  color: rgba(255,255,255,0.4);
  font-weight: 600;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
td {
  padding: 10px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.05);
  color: rgba(255,255,255,0.8);
}
tr:hover td { background: rgba(255,255,255,0.03); }
.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
}
.badge-green { background: rgba(100,200,100,0.15); color:#80ff80; }
.badge-yellow { background: rgba(245,200,66,0.15); color:#f5c842; }
.card-box {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 12px;
  overflow: hidden;
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <span class="brand-icon">☕</span>
    <div>
      <div class="brand-name">Kedai Dua Arah</div>
      <div class="brand-sub">Panel Admin</div>
    </div>
  </div>
  <nav class="nav">
    <a href="index.php" class="active">📊 Dashboard</a>
    <a href="menu.php">🍜 Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">Keluar</a>
  </nav>
</header>

<div class="content">
  <div class="page-title">📊 Dashboard</div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-label">Transaksi Hari Ini</div>
      <div class="stat-value"><?= $total_trx_hari ?></div>
      <div class="stat-sub">transaksi</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Omset Hari Ini</div>
      <div class="stat-value" style="font-size:19px"><?= fmt($omset_hari) ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Omset</div>
      <div class="stat-value" style="font-size:19px"><?= fmt($omset_total) ?></div>
      <div class="stat-sub">semua waktu</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Menu Aktif</div>
      <div class="stat-value"><?= $total_menu ?></div>
      <div class="stat-sub">item</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:28px">
    <!-- MENU TERLARIS -->
    <div class="section">
      <div class="section-title">🏆 Menu Terlaris</div>
      <div class="card-box">
        <table>
          <thead>
            <tr><th>#</th><th>Menu</th><th>Terjual</th><th>Omset</th></tr>
          </thead>
          <tbody>
            <?php foreach($top_menu as $i=>$m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><?= htmlspecialchars($m['nama_menu']) ?></td>
              <td><span class="badge badge-yellow"><?= $m['total_qty'] ?>x</span></td>
              <td><?= fmt($m['total_omset']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($top_menu)): ?>
            <tr><td colspan="4" style="text-align:center;color:rgba(255,255,255,0.3);padding:20px">Belum ada data</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TRANSAKSI TERBARU -->
    <div class="section">
      <div class="section-title">
        🧾 Transaksi Terbaru
        <a href="laporan.php" class="btn-sm btn-primary">Lihat Semua</a>
      </div>
      <div class="card-box">
        <table>
          <thead>
            <tr><th>Kode</th><th>Total</th><th>Kasir</th><th>Waktu</th></tr>
          </thead>
          <tbody>
            <?php foreach($recent_trx as $t): ?>
            <tr>
              <td style="font-size:11px;color:#f5c842"><?= htmlspecialchars($t['kode']) ?></td>
              <td><?= fmt($t['total']) ?></td>
              <td><?= htmlspecialchars($t['kasir']) ?></td>
              <td style="font-size:11px;color:rgba(255,255,255,0.4)"><?= date('d/m H:i', strtotime($t['waktu'])) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($recent_trx)): ?>
            <tr><td colspan="4" style="text-align:center;color:rgba(255,255,255,0.3);padding:20px">Belum ada transaksi</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
