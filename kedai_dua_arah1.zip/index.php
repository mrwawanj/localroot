<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header('Location: /kedai_dua_arah/admin/index.php');
    } else {
        header('Location: /kedai_dua_arah/kasir/index.php');
    }
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header('Location: /kedai_dua_arah/admin/index.php');
            } else {
                header('Location: /kedai_dua_arah/kasir/index.php');
            }
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    } else {
        $error = 'Isi semua field.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kedai Dua Arah – Login</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    min-height: 100vh;
    background: linear-gradient(135deg, #1a0a00 0%, #3d1f00 50%, #1a0a00 100%);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Segoe UI', sans-serif;
  }
  .card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,180,50,0.2);
    border-radius: 20px;
    padding: 48px 40px;
    width: 360px;
    text-align: center;
    box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  }
  .logo {
    font-size: 48px;
    margin-bottom: 8px;
  }
  h1 {
    color: #f5c842;
    font-size: 22px;
    font-weight: 700;
    letter-spacing: 1px;
  }
  .subtitle {
    color: rgba(255,255,255,0.4);
    font-size: 12px;
    margin-bottom: 32px;
    text-transform: uppercase;
    letter-spacing: 2px;
  }
  .form-group { margin-bottom: 16px; text-align: left; }
  label {
    display: block;
    color: rgba(255,255,255,0.6);
    font-size: 12px;
    margin-bottom: 6px;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  input {
    width: 100%;
    padding: 12px 16px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,180,50,0.2);
    border-radius: 10px;
    color: white;
    font-size: 15px;
    outline: none;
    transition: border-color 0.2s;
  }
  input:focus { border-color: #f5c842; }
  input::placeholder { color: rgba(255,255,255,0.3); }
  .btn {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #f5c842, #e8a020);
    border: none;
    border-radius: 10px;
    color: #1a0a00;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    margin-top: 8px;
    transition: transform 0.1s, box-shadow 0.2s;
    letter-spacing: 0.5px;
  }
  .btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(245,200,66,0.3); }
  .btn:active { transform: translateY(0); }
  .error {
    background: rgba(255,80,80,0.15);
    border: 1px solid rgba(255,80,80,0.3);
    color: #ff8080;
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 16px;
  }
  .hint {
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.08);
    color: rgba(255,255,255,0.3);
    font-size: 11px;
    line-height: 1.8;
  }
</style>
</head>
<body>
<div class="card">
  <div class="logo">☕</div>
  <h1>Kedai Dua Arah</h1>
  <p class="subtitle">Sistem Kasir</p>

  <?php if ($error): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label>Username</label>
      <input type="text" name="username" placeholder="Masukkan username" autocomplete="off" required>
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" name="password" placeholder="Masukkan password" required>
    </div>
    <button type="submit" class="btn">Masuk</button>
  </form>

  <div class="hint">
    Admin: admin / admin123<br>
    Kasir: kasir / kasir123
  </div>
</div>
</body>
</html>
