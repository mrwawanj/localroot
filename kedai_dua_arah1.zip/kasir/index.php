<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

// Load semua menu sekaligus — filter dilakukan di JS, bukan reload halaman
$kategoris = ['Semua', 'Makanan', 'Minuman', 'Cemilan'];
$menu_list = $pdo->query("SELECT * FROM menu WHERE aktif=1 AND stok>0 ORDER BY kategori, nama")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kasir – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: 'Segoe UI', sans-serif;
  background: #0f0700;
  color: #fff;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
header {
  background: linear-gradient(135deg, #1f0d00, #3d1f00);
  border-bottom: 1px solid rgba(245,200,66,0.2);
  padding: 12px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
}
.brand { display:flex; align-items:center; gap:10px; }
.brand-icon { font-size:24px; }
.brand-name { font-size:18px; font-weight:700; color:#f5c842; }
.brand-sub { font-size:11px; color:rgba(255,255,255,0.4); }
.nav-links { display:flex; align-items:center; gap:12px; }
.nav-links a {
  color: rgba(255,255,255,0.5);
  text-decoration:none;
  font-size:13px;
  padding: 6px 12px;
  border-radius: 6px;
  transition: background 0.2s;
}
.nav-links a:hover { background: rgba(255,255,255,0.08); color:#fff; }
.kasir-name {
  color: rgba(255,255,255,0.6);
  font-size: 13px;
}
.main {
  display: flex;
  flex: 1;
  overflow: hidden;
}

/* MENU PANEL */
.menu-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border-right: 1px solid rgba(255,255,255,0.08);
}
.menu-header {
  padding: 16px 20px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  flex-shrink: 0;
}
.search-box {
  width: 100%;
  padding: 10px 14px;
  background: rgba(255,255,255,0.07);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px;
  color: white;
  font-size: 14px;
  outline: none;
  margin-bottom: 12px;
}
.search-box::placeholder { color:rgba(255,255,255,0.3); }
.search-box:focus { border-color: #f5c842; }
.kategori-tabs { display:flex; gap:8px; }
.tab {
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 12px;
  cursor: pointer;
  border: 1px solid rgba(255,255,255,0.15);
  background: transparent;
  color: rgba(255,255,255,0.5);
  transition: all 0.2s;
  text-decoration: none;
}
.tab.active, .tab:hover {
  background: #f5c842;
  color: #1a0a00;
  border-color: #f5c842;
  font-weight: 600;
}
.menu-grid {
  flex: 1;
  overflow-y: auto;
  padding: 16px 20px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 12px;
  align-content: start;
}
.menu-grid::-webkit-scrollbar { width:4px; }
.menu-grid::-webkit-scrollbar-track { background: transparent; }
.menu-grid::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius:2px; }

.menu-card {
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
  user-select: none;
  display: flex;
  flex-direction: column;
  height: 145px; /* fixed total height: 65px foto + 80px info */
}
.menu-card:hover {
  border-color: rgba(245,200,66,0.4);
  background: rgba(245,200,66,0.08);
  transform: translateY(-2px);
}
.menu-card:active { transform: scale(0.97); }
.menu-foto {
  width: 100%;
  height: 65px;
  max-height: 65px;
  object-fit: cover;
  display: block;
  flex-shrink: 0;
}
.menu-foto-placeholder {
  width: 100%;
  height: 65px;
  max-height: 65px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  background: rgba(255,255,255,0.03);
  flex-shrink: 0;
}
.menu-info {
  padding: 8px 10px 10px;
  display: flex;
  flex-direction: column;
  min-height: 60px;
  flex: 1;
}
.menu-nama {
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  margin-bottom: 4px;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.menu-harga {
  font-size: 13px;
  font-weight: 700;
  color: #f5c842;
  margin-top: auto;
  white-space: nowrap;
}
.menu-stok {
  font-size: 10px;
  color: rgba(255,255,255,0.3);
  margin-top: 2px;
}

/* CART PANEL */
.cart-panel {
  width: 320px;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  background: rgba(255,255,255,0.02);
}
.cart-header {
  padding: 16px 20px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  flex-shrink: 0;
}
.cart-title {
  font-size: 15px;
  font-weight: 700;
  color: #f5c842;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.cart-clear {
  font-size: 11px;
  color: rgba(255,100,100,0.7);
  cursor: pointer;
  padding: 3px 8px;
  border-radius: 4px;
  border: 1px solid rgba(255,100,100,0.3);
  background: none;
}
.cart-clear:hover { background: rgba(255,100,100,0.1); color:#ff8080; }
.cart-items {
  flex: 1;
  overflow-y: auto;
  padding: 12px;
}
.cart-items::-webkit-scrollbar { width:3px; }
.cart-items::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); }
.cart-empty {
  text-align: center;
  padding: 40px 0;
  color: rgba(255,255,255,0.2);
  font-size: 13px;
}
.cart-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 8px;
  border-bottom: 1px solid rgba(255,255,255,0.05);
}
.cart-item-left {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
}
.cart-item-emoji { font-size: 20px; flex-shrink:0; }
.cart-item-info { flex:1; min-width:0; }
.cart-item-nama {
  font-size: 13px;
  font-weight: 600;
  line-height: 1.3;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.cart-item-harga-satuan {
  font-size: 11px;
  color: rgba(255,255,255,0.35);
  margin-top: 2px;
}
.cart-item-right {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 5px;
  flex-shrink: 0;
}
.cart-item-sub {
  font-size: 14px;
  font-weight: 700;
  color: #f5c842;
}
.qty-ctrl { display:flex; align-items:center; gap:5px; }
.qty-btn {
  width: 22px; height: 22px;
  border-radius: 50%;
  border: 1px solid rgba(255,255,255,0.2);
  background: none;
  color: white;
  font-size: 15px;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  line-height: 1;
  transition: background 0.15s;
}
.qty-btn:hover { background: rgba(255,255,255,0.12); }
.qty-num { font-size: 13px; font-weight: 700; min-width: 18px; text-align:center; }
.cart-footer {
  padding: 14px 16px;
  border-top: 1px solid rgba(255,255,255,0.1);
  flex-shrink: 0;
  background: rgba(0,0,0,0.2);
}
.total-box {
  background: rgba(245,200,66,0.08);
  border: 1px solid rgba(245,200,66,0.2);
  border-radius: 10px;
  padding: 12px 14px;
  margin-bottom: 10px;
}
.total-items-info {
  font-size: 11px;
  color: rgba(255,255,255,0.35);
  margin-bottom: 6px;
}
.total-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.total-label { font-size: 12px; color: rgba(255,255,255,0.5); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
.total-value { font-size: 22px; font-weight: 800; color: #f5c842; }
/* Toggle metode bayar */
.metode-toggle {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
}
.metode-btn {
  flex: 1;
  padding: 9px 0;
  border-radius: 8px;
  border: 1px solid rgba(255,255,255,0.15);
  background: transparent;
  color: rgba(255,255,255,0.45);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}
.metode-btn.active {
  background: rgba(245,200,66,0.15);
  border-color: #f5c842;
  color: #f5c842;
}
.metode-btn:hover:not(.active) { background: rgba(255,255,255,0.07); color: #fff; }

.bayar-label {
  font-size: 11px;
  color: rgba(255,255,255,0.4);
  margin-bottom: 5px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.bayar-input {
  width: 100%;
  padding: 10px 14px;
  background: rgba(255,255,255,0.07);
  border: 1px solid rgba(255,255,255,0.15);
  border-radius: 8px;
  color: white;
  font-size: 16px;
  outline: none;
  margin-bottom: 8px;
}
.bayar-input:focus { border-color: #f5c842; }
.bayar-input::placeholder { color: rgba(255,255,255,0.25); }
.kembalian-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  color: #80ff80;
  margin-bottom: 10px;
  padding: 8px 12px;
  background: rgba(100,200,100,0.08);
  border: 1px solid rgba(100,200,100,0.15);
  border-radius: 7px;
}
.kurang-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  color: #ff8080;
  margin-bottom: 10px;
  padding: 8px 12px;
  background: rgba(255,80,80,0.08);
  border: 1px solid rgba(255,80,80,0.2);
  border-radius: 7px;
}
.btn-bayar {
  width: 100%;
  padding: 13px;
  background: linear-gradient(135deg, #f5c842, #e8a020);
  border: none;
  border-radius: 10px;
  color: #1a0a00;
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  transition: all 0.2s;
  letter-spacing: 0.5px;
}
.btn-bayar:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(245,200,66,0.3); }
.btn-bayar:disabled { opacity:0.4; cursor:not-allowed; transform:none; }

/* MODAL STRUK */
.modal-overlay {
  position:fixed; inset:0;
  background: rgba(0,0,0,0.7);
  display:none;
  align-items:center;
  justify-content:center;
  z-index: 999;
}
.modal-overlay.show { display:flex; }
.struk {
  background: white;
  color: #000;
  padding: 24px 20px;
  width: 300px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  border-radius: 8px;
  position: relative;
}
.struk-header { text-align:center; margin-bottom:12px; }
.struk-nama { font-size:16px; font-weight:bold; }
.struk-sub { font-size:11px; color:#555; }
.struk-divider { border:none; border-top:1px dashed #999; margin:8px 0; }
.struk-row { display:flex; justify-content:space-between; margin:3px 0; }
.struk-row.total { font-weight:bold; font-size:13px; border-top:1px solid #000; padding-top:6px; margin-top:6px; }
.struk-footer { text-align:center; margin-top:12px; font-size:11px; color:#555; }
.struk-actions { display:flex; gap:8px; margin-top:16px; }
.struk-actions button {
  flex:1; padding:10px;
  border-radius:8px;
  font-size:13px;
  font-weight:600;
  cursor:pointer;
  border:none;
}
.btn-print { background:#1a0a00; color:white; }
.btn-close-struk { background:#eee; color:#333; }

@media print {
  body > *:not(.modal-overlay) { display:none !important; }
  .modal-overlay { background:white !important; }
  .struk-actions { display:none !important; }
  .struk { box-shadow:none; border-radius:0; }
}

/* ===== MOBILE RESPONSIVE ===== */
@media (max-width: 768px) {
  body { height: auto; min-height: 100vh; }

  .main {
    flex-direction: column;
    height: auto;
    overflow: visible;
  }

  /* MENU PANEL full width */
  .menu-panel {
    border-right: none;
    border-bottom: 1px solid rgba(255,255,255,0.08);
    overflow: visible;
    height: auto;
  }

  .menu-header { padding: 12px 14px 10px; }

  .search-box { font-size: 16px; /* cegah zoom di iOS */ }

  .kategori-tabs { gap: 6px; flex-wrap: wrap; }
  .tab { font-size: 11px; padding: 5px 12px; }

  .menu-grid {
    overflow: visible;
    padding: 12px 14px;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }

  .menu-card { height: 130px; }
  .menu-foto, .menu-foto-placeholder { height: 55px; max-height: 55px; }
  .menu-info { padding: 6px 8px 8px; min-height: 50px; }
  .menu-nama { font-size: 11px; }
  .menu-harga { font-size: 12px; }
  .menu-stok { font-size: 9px; }

  /* CART PANEL full width di bawah */
  .cart-panel {
    width: 100%;
    flex-shrink: 0;
    border-top: 2px solid rgba(245,200,66,0.3);
  }

  .cart-items {
    max-height: 220px;
    overflow-y: auto;
  }

  /* total + bayar lebih compact */
  .total-box { padding: 10px 14px; }
  .total-label { font-size: 11px; }
  .total-value { font-size: 20px; }
  .bayar-section { padding: 10px 14px; }

  /* struk modal full screen di mobile */
  .struk {
    width: 95vw;
    max-width: 340px;
    padding: 16px;
  }
}
</style>
</head>
<body>
<header>
  <div class="brand">
    <span class="brand-icon">☕</span>
    <div>
      <div class="brand-name">Kedai Dua Arah</div>
      <div class="brand-sub">Sistem Kasir</div>
    </div>
  </div>
  <div class="nav-links">
    <span class="kasir-name">👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
    <?php if(isAdmin()): ?>
    <a href="/kedai_dua_arah/admin/index.php">⚙ Admin</a>
    <?php endif; ?>
    <a href="/kedai_dua_arah/logout.php">Keluar</a>
  </div>
</header>

<div class="main">
  <!-- PANEL MENU -->
  <div class="menu-panel">
    <div class="menu-header">
      <input type="text" class="search-box" id="searchBox" placeholder="🔍 Cari menu...">
      <div class="kategori-tabs">
        <?php foreach($kategoris as $k): ?>
        <button class="tab <?= $k==='Semua'?'active':'' ?>"
                onclick="filterKategori('<?= $k ?>', this)">
          <?= $k ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="menu-grid" id="menuGrid">
      <?php foreach($menu_list as $m): ?>
      <div class="menu-card"
           data-id="<?= $m['id'] ?>"
           data-nama="<?= htmlspecialchars($m['nama']) ?>"
           data-harga="<?= $m['harga'] ?>"
           data-stok="<?= $m['stok'] ?>"
           data-kategori="<?= htmlspecialchars($m['kategori']) ?>"
           onclick="addToCart(this)">
        <?php if($m['foto'] && file_exists('../assets/foto/' . $m['foto'])): ?>
        <img class="menu-foto" src="/kedai_dua_arah/assets/foto/<?= htmlspecialchars($m['foto']) ?>" alt="<?= htmlspecialchars($m['nama']) ?>">
        <?php else: ?>
        <div class="menu-foto-placeholder">
          <?= $m['kategori']==='Makanan'?'🍜':($m['kategori']==='Minuman'?'🥤':'🍟') ?>
        </div>
        <?php endif; ?>
        <div class="menu-info">
          <div class="menu-nama"><?= htmlspecialchars($m['nama']) ?></div>
          <div class="menu-harga">Rp <?= number_format($m['harga'],0,',','.') ?></div>
          <div class="menu-stok">Stok: <?= $m['stok'] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- PANEL KERANJANG -->
  <div class="cart-panel">
    <div class="cart-header">
      <div class="cart-title">
        <span>🛒 Pesanan</span>
        <button class="cart-clear" onclick="clearCart()">Hapus Semua</button>
      </div>
    </div>
    <div class="cart-items" id="cartItems">
      <div class="cart-empty" id="cartEmpty">Belum ada pesanan</div>
    </div>
    <div class="cart-footer">
      <div class="total-box">
        <div class="total-items-info" id="totalItemsInfo">0 item</div>
        <div class="total-row">
          <span class="total-label">Total</span>
          <span class="total-value" id="totalDisplay">Rp 0</span>
        </div>
      </div>
      <!-- Toggle metode bayar -->
      <div class="metode-toggle">
        <button class="metode-btn active" id="btnCash" onclick="setMetode('cash')">💵 Cash</button>
        <button class="metode-btn" id="btnQris" onclick="setMetode('qris')">📱 QRIS</button>
      </div>

      <!-- Input bayar — hanya tampil saat Cash -->
      <div id="cashSection">
        <div class="bayar-label">Uang Bayar <span style="color:rgba(255,255,255,0.25)">(opsional)</span></div>
        <input type="number" class="bayar-input" id="bayarInput"
               placeholder="Kosongkan jika uang pas" oninput="hitungKembalian()">
        <div class="kembalian-row" id="kembalianRow" style="display:none">
          <span>💚 Kembalian</span>
          <span id="kembalianDisplay" style="font-weight:700"></span>
        </div>
        <div class="kurang-row" id="kurangRow" style="display:none">
          <span>⚠️ Kurang</span>
          <span id="kurangDisplay" style="font-weight:700"></span>
        </div>
      </div>

      <!-- Info QRIS -->
      <div id="qrisSection" style="display:none">
        <div style="text-align:center;padding:10px 0 14px;color:rgba(255,255,255,0.4);font-size:12px;">
          📱 Pembayaran via QRIS — tanpa kembalian
        </div>
      </div>

      <button class="btn-bayar" id="btnBayar" onclick="prosesBayar()" disabled>
        💳 Bayar
      </button>
    </div>
  </div>
</div>

<!-- MODAL STRUK -->
<div class="modal-overlay" id="modalStruk">
  <div class="struk" id="strukContent">
    <div class="struk-header">
      <div class="struk-nama">☕ Kedai Dua Arah</div>
      <div class="struk-sub">Terima kasih atas kunjungan Anda</div>
    </div>
    <hr class="struk-divider">
    <div id="strukKode" style="text-align:center;font-size:11px;margin-bottom:6px;"></div>
    <div id="strukWaktu" style="text-align:center;font-size:10px;color:#666;margin-bottom:8px;"></div>
    <div id="strukItems"></div>
    <hr class="struk-divider">
    <div class="struk-row total"><span>TOTAL</span><span id="strukTotal"></span></div>
    <div class="struk-row"><span>Bayar</span><span id="strukBayar"></span></div>
    <div class="struk-row"><span>Kembalian</span><span id="strukKembalian"></span></div>
    <div class="struk-footer">
      <div id="strukKasir"></div>
      <div>— Selamat datang kembali —</div>
    </div>
    <div class="struk-actions">
      <button class="btn-print" onclick="window.print()">🖨 Print</button>
      <button class="btn-close-struk" onclick="tutupStruk()">Transaksi Baru</button>
    </div>
  </div>
</div>

<script>
let cart = {};
let totalHarga = 0;
let metodeBayar = 'cash'; // 'cash' | 'qris'

function fmt(n) {
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

function setMetode(m) {
  metodeBayar = m;
  document.getElementById('btnCash').classList.toggle('active', m === 'cash');
  document.getElementById('btnQris').classList.toggle('active', m === 'qris');
  document.getElementById('cashSection').style.display = m === 'cash' ? '' : 'none';
  document.getElementById('qrisSection').style.display = m === 'qris' ? '' : 'none';

  // reset input bayar kalau ganti ke QRIS
  if (m === 'qris') {
    document.getElementById('bayarInput').value = '';
    document.getElementById('kembalianRow').style.display = 'none';
    document.getElementById('kurangRow').style.display   = 'none';
  }
  hitungKembalian();
}

function getEmoji(nama) {
  if (nama.toLowerCase().includes('kopi') || nama.toLowerCase().includes('cappuccino')) return '☕';
  if (nama.toLowerCase().includes('teh')) return '🍵';
  if (nama.toLowerCase().includes('indomie') || nama.toLowerCase().includes('mie')) return '🍜';
  if (nama.toLowerCase().includes('nasi')) return '🍚';
  if (nama.toLowerCase().includes('jeruk') || nama.toLowerCase().includes('es ')) return '🧃';
  if (nama.toLowerCase().includes('gorengan')) return '🍟';
  if (nama.toLowerCase().includes('roti')) return '🍞';
  return '🥘';
}

function addToCart(el) {
  const id = el.dataset.id;
  const nama = el.dataset.nama;
  const harga = parseInt(el.dataset.harga);
  const stok = parseInt(el.dataset.stok);

  if (cart[id]) {
    if (cart[id].qty >= stok) {
      alert('Stok tidak mencukupi!');
      return;
    }
    cart[id].qty++;
  } else {
    cart[id] = { nama, harga, qty: 1, stok };
  }
  renderCart();
}

function changeQty(id, delta) {
  if (!cart[id]) return;
  cart[id].qty += delta;
  if (cart[id].qty <= 0) delete cart[id];
  else if (cart[id].qty > cart[id].stok) cart[id].qty = cart[id].stok;
  renderCart();
}

function clearCart() {
  cart = {};
  document.getElementById('bayarInput').value = '';
  document.getElementById('kembalianRow').style.display = 'none';
  document.getElementById('kurangRow').style.display = 'none';
  // reset ke cash
  setMetode('cash');
  renderCart();
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const empty = document.getElementById('cartEmpty');
  totalHarga = 0;

  if (Object.keys(cart).length === 0) {
    container.innerHTML = '<div class="cart-empty">Belum ada pesanan</div>';
    document.getElementById('totalDisplay').textContent = 'Rp 0';
    document.getElementById('btnBayar').disabled = true;
    document.getElementById('kembalianRow').style.display = 'none';
    return;
  }

  let html = '';
  let totalQty = 0;
  for (const id in cart) {
    const item = cart[id];
    const sub = item.harga * item.qty;
    totalHarga += sub;
    totalQty += item.qty;
    html += `
    <div class="cart-item">
      <div class="cart-item-left">
        <div class="cart-item-emoji">${getEmoji(item.nama)}</div>
        <div class="cart-item-info">
          <div class="cart-item-nama">${item.nama}</div>
          <div class="cart-item-harga-satuan">${fmt(item.harga)} / pcs</div>
        </div>
      </div>
      <div class="cart-item-right">
        <div class="cart-item-sub">${fmt(sub)}</div>
        <div class="qty-ctrl">
          <button class="qty-btn" onclick="changeQty('${id}',-1)">−</button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="changeQty('${id}',1)">+</button>
        </div>
      </div>
    </div>`;
  }
  document.getElementById('totalItemsInfo').textContent = totalQty + ' item · ' + Object.keys(cart).length + ' menu';

  container.innerHTML = html;
  document.getElementById('totalDisplay').textContent = fmt(totalHarga);
  document.getElementById('btnBayar').disabled = false;
  hitungKembalian();
}

function hitungKembalian() {
  const kemRow = document.getElementById('kembalianRow');
  const kurRow = document.getElementById('kurangRow');
  kemRow.style.display = 'none';
  kurRow.style.display = 'none';

  if (Object.keys(cart).length === 0) {
    document.getElementById('btnBayar').disabled = true;
    return;
  }

  // QRIS: langsung enable, nggak perlu input bayar
  if (metodeBayar === 'qris') {
    document.getElementById('btnBayar').disabled = false;
    return;
  }

  // Cash
  const bayarRaw = document.getElementById('bayarInput').value;
  const bayar = parseInt(bayarRaw) || 0;
  const kembalian = bayar - totalHarga;

  if (bayarRaw === '' || bayar === 0) {
    // Kosong = uang pas, boleh lanjut
    document.getElementById('btnBayar').disabled = false;
  } else if (kembalian >= 0) {
    kemRow.style.display = 'flex';
    document.getElementById('kembalianDisplay').textContent = fmt(kembalian);
    document.getElementById('btnBayar').disabled = false;
  } else {
    kurRow.style.display = 'flex';
    document.getElementById('kurangDisplay').textContent = fmt(Math.abs(kembalian));
    document.getElementById('btnBayar').disabled = true;
  }
}

function prosesBayar() {
  if (Object.keys(cart).length === 0) return;

  const bayarRaw = document.getElementById('bayarInput').value;
  const bayar = parseInt(bayarRaw) || 0;

  // Safety check untuk cash
  if (metodeBayar === 'cash' && bayar > 0 && bayar < totalHarga) return;

  const items = Object.values(cart).map(i => ({
    id: Object.keys(cart).find(k => cart[k] === i),
    nama: i.nama,
    harga: i.harga,
    qty: i.qty,
    subtotal: i.harga * i.qty
  }));

  const kembalian = (metodeBayar === 'cash' && bayar > 0) ? bayar - totalHarga : 0;
  const bayarFinal = metodeBayar === 'qris' ? totalHarga : (bayar || totalHarga);

  fetch('/kedai_dua_arah/kasir/proses_bayar.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ items, total: totalHarga, bayar: bayarFinal, kembalian, metode: metodeBayar })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      tampilStruk(data.kode, items, totalHarga, bayarFinal, kembalian, metodeBayar);
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(() => alert('Gagal menyimpan transaksi.'));
}

function tampilStruk(kode, items, total, bayar, kembalian, metode) {
  const now = new Date();
  const waktu = now.toLocaleString('id-ID', {
    day:'2-digit', month:'long', year:'numeric',
    hour:'2-digit', minute:'2-digit'
  });

  document.getElementById('strukKode').textContent = 'No: ' + kode;
  document.getElementById('strukWaktu').textContent = waktu;
  document.getElementById('strukKasir').textContent = 'Kasir: <?= htmlspecialchars($_SESSION['username']) ?>';

  let itemsHtml = '';
  items.forEach(i => {
    itemsHtml += `
    <div class="struk-row">
      <span>${i.nama} x${i.qty}</span>
      <span>${fmt(i.subtotal)}</span>
    </div>`;
  });
  document.getElementById('strukItems').innerHTML = itemsHtml;
  document.getElementById('strukTotal').textContent = fmt(total);
  if (metode === 'qris') {
    document.getElementById('strukBayar').textContent = '📱 QRIS';
    document.getElementById('strukKembalian').textContent = '-';
  } else {
    document.getElementById('strukBayar').textContent = bayar > 0 ? fmt(bayar) : fmt(total) + ' (Pas)';
    document.getElementById('strukKembalian').textContent = bayar > 0 ? fmt(kembalian) : '-';
  }

  document.getElementById('modalStruk').classList.add('show');
}

function tutupStruk() {
  document.getElementById('modalStruk').classList.remove('show');
  clearCart();
  location.reload();
}

// State filter kategori aktif
let kategoriAktif = 'Semua';

function filterKategori(kat, btn) {
  kategoriAktif = kat;
  // update active tab
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  // terapkan filter
  applyFilter();
}

function applyFilter() {
  const q = document.getElementById('searchBox').value.toLowerCase();
  document.querySelectorAll('.menu-card').forEach(card => {
    const nama = card.dataset.nama.toLowerCase();
    const kat  = card.dataset.kategori;
    const cocokKat  = (kategoriAktif === 'Semua' || kat === kategoriAktif);
    const cocokCari = nama.includes(q);
    card.style.display = (cocokKat && cocokCari) ? '' : 'none';
  });
}

// Search filter — pakai applyFilter biar sinkron sama tab aktif
document.getElementById('searchBox').addEventListener('input', applyFilter);
</script>
</body>
</html>
