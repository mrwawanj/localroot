<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success'=>false,'message'=>'Data tidak valid']);
    exit;
}

$items     = $input['items'] ?? [];
$total     = (int)($input['total'] ?? 0);
$bayar     = (int)($input['bayar'] ?? 0);
$kembalian = (int)($input['kembalian'] ?? 0);
$metode    = in_array($input['metode'] ?? '', ['cash','qris']) ? $input['metode'] : 'cash';

if (empty($items) || $total <= 0 || $bayar < $total) {
    echo json_encode(['success'=>false,'message'=>'Data transaksi tidak valid']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Cek stok semua item
    foreach ($items as $item) {
        $stmt = $pdo->prepare("SELECT stok FROM menu WHERE id=? AND aktif=1");
        $stmt->execute([$item['id']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row || $row['stok'] < $item['qty']) {
            $pdo->rollBack();
            echo json_encode(['success'=>false,'message'=>'Stok '.$item['nama'].' tidak mencukupi']);
            exit;
        }
    }

    // Generate kode transaksi
    $kode = 'TRX-' . date('YmdHis') . '-' . rand(100,999);

    // Insert transaksi (dengan metode bayar)
    $stmt = $pdo->prepare("INSERT INTO transaksi (kode,total,bayar,kembalian,kasir,metode) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$kode, $total, $bayar, $kembalian, $_SESSION['username'], $metode]);
    $trx_id = $pdo->lastInsertId();

    // Insert detail + kurangi stok
    foreach ($items as $item) {
        $menu_id = (int)$item['id'];
        $qty     = (int)$item['qty'];
        $harga   = (int)$item['harga'];
        $subtotal = (int)$item['subtotal'];
        $nama_menu = (string)$item['nama'];

        $stmt = $pdo->prepare("INSERT INTO detail_transaksi (transaksi_id,menu_id,nama_menu,harga,qty,subtotal) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$trx_id, $menu_id, $nama_menu, $harga, $qty, $subtotal]);

        // Update stok dengan cast eksplisit
        $stmt = $pdo->prepare("UPDATE menu SET stok = MAX(0, stok - :qty) WHERE id = :id");
        $stmt->bindValue(':qty', $qty, PDO::PARAM_INT);
        $stmt->bindValue(':id', $menu_id, PDO::PARAM_INT);
        $stmt->execute();

        // Verifikasi update benar-benar jalan
        if ($stmt->rowCount() === 0) {
            // Coba fallback dengan integer literal
            $pdo->exec("UPDATE menu SET stok = MAX(0, stok - $qty) WHERE id = $menu_id");
        }
    }

    $pdo->commit();
    echo json_encode(['success'=>true, 'kode'=>$kode]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
?>
