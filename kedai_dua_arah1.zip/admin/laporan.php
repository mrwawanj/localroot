<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

$filter_tgl = $_GET['tgl'] ?? date('Y-m-d');
$filter_dari = $_GET['dari'] ?? date('Y-m-01');
$filter_sampai = $_GET['sampai'] ?? date('Y-m-d');
$filter_tahun = (int)($_GET['tahun'] ?? date('Y'));
$mode = $_GET['mode'] ?? 'hari';

$msg = '';
$err = '';

// Daftar tahun yang ada di DB
$tahun_list = $pdo->query("SELECT DISTINCT strftime('%Y', waktu) as thn FROM transaksi ORDER BY thn DESC")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array($filter_tahun, array_map('intval', $tahun_list))) {
    $tahun_list[] = date('Y');
    $tahun_list = array_unique($tahun_list);
    rsort($tahun_list);
}

// RESET TRANSAKSI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset') {
    $tipe = $_POST['tipe'] ?? '';
    if ($tipe === 'semua') {
        $pdo->exec("DELETE FROM detail_transaksi");
        $pdo->exec("DELETE FROM transaksi");
        $msg = '✅ Semua data transaksi berhasil direset.';
    } elseif ($tipe === 'hari' && !empty($_POST['tgl_reset'])) {
        $tgl = $_POST['tgl_reset'];
        $pdo->prepare("DELETE FROM detail_transaksi WHERE transaksi_id IN (SELECT id FROM transaksi WHERE DATE(waktu)=?)")->execute([$tgl]);
        $pdo->prepare("DELETE FROM transaksi WHERE DATE(waktu)=?")->execute([$tgl]);
        $msg = "✅ Transaksi tanggal $tgl berhasil direset.";
    } else {
        $err = 'Pilihan reset tidak valid.';
    }
}

$list = [];
$total_omset = 0;
$total_trx = 0;
$omset_per_bulan = []; // untuk mode tahun

if ($mode === 'tahun') {
    // Omset per bulan dalam tahun dipilih
    $stmt = $pdo->prepare("
        SELECT
            strftime('%m', waktu) as bulan,
            COUNT(*) as jumlah_trx,
            COALESCE(SUM(total), 0) as omset
        FROM transaksi
        WHERE strftime('%Y', waktu) = ?
        GROUP BY bulan
        ORDER BY bulan
    ");
    $stmt->execute([(string)$filter_tahun]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Isi semua bulan Jan-Des, kosong = 0
    $nama_bulan = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April',
                   '05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus',
                   '09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
    foreach ($nama_bulan as $k => $v) {
        $omset_per_bulan[$k] = ['nama'=>$v, 'jumlah_trx'=>0, 'omset'=>0];
    }
    foreach ($rows as $r) {
        $omset_per_bulan[$r['bulan']]['jumlah_trx'] = (int)$r['jumlah_trx'];
        $omset_per_bulan[$r['bulan']]['omset'] = (int)$r['omset'];
    }

    $total_omset = array_sum(array_column($omset_per_bulan, 'omset'));
    $total_trx   = array_sum(array_column($omset_per_bulan, 'jumlah_trx'));

} elseif ($mode === 'hari') {
    $transaksis = $pdo->prepare("
        SELECT t.*, GROUP_CONCAT(d.nama_menu || ' x' || d.qty, ', ') as items
        FROM transaksi t
        LEFT JOIN detail_transaksi d ON d.transaksi_id = t.id
        WHERE DATE(t.waktu) = ?
        GROUP BY t.id
        ORDER BY t.waktu DESC
    ");
    $transaksis->execute([$filter_tgl]);
    $omset = $pdo->prepare("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(waktu)=?");
    $omset->execute([$filter_tgl]);
    $list = $transaksis->fetchAll(PDO::FETCH_ASSOC);
    $total_omset = $omset->fetchColumn();
    $total_trx = count($list);
} else {
    $transaksis = $pdo->prepare("
        SELECT t.*, GROUP_CONCAT(d.nama_menu || ' x' || d.qty, ', ') as items
        FROM transaksi t
        LEFT JOIN detail_transaksi d ON d.transaksi_id = t.id
        WHERE DATE(t.waktu) BETWEEN ? AND ?
        GROUP BY t.id
        ORDER BY t.waktu DESC
    ");
    $transaksis->execute([$filter_dari, $filter_sampai]);
    $omset = $pdo->prepare("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(waktu) BETWEEN ? AND ?");
    $omset->execute([$filter_dari, $filter_sampai]);
    $list = $transaksis->fetchAll(PDO::FETCH_ASSOC);
    $total_omset = $omset->fetchColumn();
    $total_trx = count($list);
}

function fmt($n) { return 'Rp ' . number_format($n,0,',','.'); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; background:#0f0700; color:#fff; min-height:100vh; }
header { background:linear-gradient(135deg,#1f0d00,#3d1f00); border-bottom:1px solid rgba(245,200,66,0.2); padding:12px 20px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:100; }
.brand-name { font-size:17px; font-weight:700; color:#f5c842; }
.nav { display:flex; gap:4px; }
.nav a { color:rgba(255,255,255,0.5); text-decoration:none; padding:7px 12px; border-radius:7px; font-size:12px; transition:all 0.2s; white-space:nowrap; }
.nav a:hover, .nav a.active { background:rgba(245,200,66,0.15); color:#f5c842; }
.nav a.logout { color:rgba(255,100,100,0.6); }
.hamburger { display:none; flex-direction:column; gap:5px; cursor:pointer; padding:6px; border:1px solid rgba(255,255,255,0.15); border-radius:7px; background:none; }
.hamburger span { display:block; width:20px; height:2px; background:rgba(255,255,255,0.7); border-radius:2px; }
.mobile-nav { display:none; position:fixed; inset:0; z-index:200; }
.mobile-nav.show { display:block; }
.mobile-nav-backdrop { position:absolute; inset:0; background:rgba(0,0,0,0.6); }
.mobile-nav-drawer { position:absolute; right:0; top:0; bottom:0; width:220px; background:#1f0d00; border-left:1px solid rgba(245,200,66,0.2); display:flex; flex-direction:column; padding:16px 0; animation:slideIn 0.25s ease; }
@keyframes slideIn { from { transform:translateX(100%); } to { transform:translateX(0); } }
.mobile-nav-title { font-size:12px; color:rgba(255,255,255,0.3); padding:0 20px 12px; text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:8px; }
.mobile-nav-drawer a { display:block; padding:14px 20px; color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; border-left:3px solid transparent; }
.mobile-nav-drawer a:hover, .mobile-nav-drawer a.active { background:rgba(245,200,66,0.08); color:#f5c842; border-left-color:#f5c842; }
.mobile-nav-drawer a.logout { color:rgba(255,100,100,0.6); }
.content { padding:14px; max-width:1100px; margin:0 auto; }
.page-title { font-size:18px; font-weight:700; color:#f5c842; margin-bottom:14px; }
.filter-bar {
  display:flex; gap:10px; align-items:flex-end; margin-bottom:14px; flex-wrap:wrap;
  background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07);
  border-radius:12px; padding:12px;
}
.filter-group { display:flex; flex-direction:column; gap:5px; }
.filter-group label { font-size:10px; color:rgba(255,255,255,0.4); text-transform:uppercase; letter-spacing:0.8px; }
.filter-group input, .filter-group select {
  padding:7px 10px; background:rgba(255,255,255,0.07);
  border:1px solid rgba(255,255,255,0.12); border-radius:7px;
  color:white; font-size:13px; outline:none;
}
.filter-group input:focus, .filter-group select:focus { border-color:#f5c842; }
select option { background:#1a0d00; }
.btn-filter { padding:7px 16px; background:#f5c842; color:#1a0a00; border:none; border-radius:7px; font-size:13px; font-weight:600; cursor:pointer; }
.stats-row { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; margin-bottom:14px; }
.stat-mini { background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:10px; padding:12px 14px; }
.stat-mini .label { font-size:10px; color:rgba(255,255,255,0.4); margin-bottom:4px; }
.stat-mini .val { font-size:18px; font-weight:700; color:#f5c842; }
.card-box { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:12px; overflow:hidden; }
table { width:100%; border-collapse:collapse; font-size:12px; }
th { text-align:left; padding:9px 10px; border-bottom:1px solid rgba(255,255,255,0.1); color:rgba(255,255,255,0.4); font-size:10px; text-transform:uppercase; letter-spacing:0.5px; }
td { padding:9px 10px; border-bottom:1px solid rgba(255,255,255,0.05); color:rgba(255,255,255,0.8); }
tr:hover td { background:rgba(255,255,255,0.03); }
.empty { text-align:center; padding:40px; color:rgba(255,255,255,0.3); }
.mode-tabs { display:flex; gap:6px; margin-bottom:12px; overflow-x:auto; padding-bottom:4px; }
.mode-tab { padding:7px 18px; border-radius:20px; font-size:12px; border:1px solid rgba(255,255,255,0.15); background:transparent; color:rgba(255,255,255,0.5); cursor:pointer; text-decoration:none; }
.mode-tab.active { background:#f5c842; color:#1a0a00; border-color:#f5c842; font-weight:600; }
.btn-reset { padding:8px 16px; background:rgba(255,60,60,0.12); border:1px solid rgba(255,60,60,0.3); color:#ff7070; border-radius:7px; font-size:13px; font-weight:600; cursor:pointer; transition:all 0.2s; }
.btn-reset:hover { background:rgba(255,60,60,0.22); color:#ff9090; }
.alert { padding:10px 16px; border-radius:8px; font-size:13px; margin-bottom:16px; }
.alert-success { background:rgba(100,200,100,0.12); border:1px solid rgba(100,200,100,0.3); color:#80ff80; }
.alert-error { background:rgba(255,80,80,0.12); border:1px solid rgba(255,80,80,0.3); color:#ff8080; }
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.75); display:none; align-items:center; justify-content:center; z-index:999; }
.modal-overlay.show { display:flex; }
.modal { background:#1a0d00; border:1px solid rgba(255,60,60,0.3); border-radius:16px; padding:28px; width:400px; max-width:95vw; }
.modal-title { font-size:16px; font-weight:700; color:#ff7070; margin-bottom:8px; }
.modal-desc { font-size:13px; color:rgba(255,255,255,0.5); margin-bottom:20px; line-height:1.6; }
.modal-tabs { display:flex; gap:8px; margin-bottom:16px; }
.modal-tab { flex:1; padding:8px; border-radius:7px; border:1px solid rgba(255,255,255,0.1); background:transparent; color:rgba(255,255,255,0.4); cursor:pointer; font-size:13px; text-align:center; }
.modal-tab.active { background:rgba(255,60,60,0.15); border-color:rgba(255,60,60,0.4); color:#ff7070; font-weight:600; }
.modal-section { display:none; }
.modal-section.show { display:block; }
.modal-actions { display:flex; gap:10px; margin-top:20px; }
.btn-confirm-reset { flex:1; padding:11px; background:rgba(255,60,60,0.2); border:1px solid rgba(255,60,60,0.5); color:#ff7070; border-radius:8px; font-size:14px; font-weight:700; cursor:pointer; }
.btn-confirm-reset:hover { background:rgba(255,60,60,0.35); }
.btn-cancel { flex:1; padding:11px; background:rgba(255,255,255,0.07); border:none; color:rgba(255,255,255,0.6); border-radius:8px; font-size:14px; cursor:pointer; }
.modal input[type=date] { width:100%; padding:9px 12px; background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:7px; color:white; font-size:13px; outline:none; }
.modal input[type=date]:focus { border-color:#f5c842; }

/* ===== MOBILE ===== */
@media (max-width:640px) {
  .nav { display:none; }
  .hamburger { display:flex; }
  .content { padding:12px; }
  .page-title { font-size:16px; }

  /* Stats 2 kolom tetap */
  .stats-row { grid-template-columns:repeat(2,1fr); }

  /* Filter bar: stack vertical */
  .filter-bar { flex-direction:column; gap:8px; }
  .filter-group { width:100%; }
  .filter-group input, .filter-group select { width:100%; }
  .btn-filter { width:100%; }

  /* Tabel transaksi (8 kolom) → card per row */
  .trx-table thead { display:none; }
  .trx-table tr {
    display:block; padding:12px;
    border-bottom:1px solid rgba(255,255,255,0.08);
    background:rgba(255,255,255,0.02);
  }
  .trx-table tr:nth-child(even) { background:rgba(255,255,255,0.04); }
  .trx-table td { display:flex; justify-content:space-between; border:none; padding:3px 0; font-size:12px; }
  .trx-table td::before { content:attr(data-label); color:rgba(255,255,255,0.35); font-size:10px; text-transform:uppercase; letter-spacing:0.5px; flex-shrink:0; margin-right:8px; }
  .trx-table td.trx-kode { font-size:13px; font-weight:700; color:#f5c842; justify-content:flex-start; }
  .trx-table td.trx-kode::before { display:none; }

  /* Tabel tahunan: sembunyikan kolom grafik, kompres */
  .hide-mobile { display:none; }
}

@media (min-width:641px) {
  .stats-row { grid-template-columns:repeat(3,1fr); }
}
</style>
</head>
<body>
<header>
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:22px">☕</span>
    <div class="brand-name">Kedai Dua Arah</div>
  </div>
  <nav class="nav">
    <a href="index.php">📊 Dashboard</a>
    <a href="menu.php">🍜 Menu</a>
    <a href="laporan.php" class="active">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">Keluar</a>
  </nav>
  <button class="hamburger" onclick="toggleNav()"><span></span><span></span><span></span></button>
</header>
<div class="mobile-nav" id="mobileNav">
  <div class="mobile-nav-backdrop" onclick="closeNav()"></div>
  <div class="mobile-nav-drawer">
    <div class="mobile-nav-title">Menu Admin</div>
    <a href="index.php">📊 Dashboard</a>
    <a href="menu.php">🍜 Kelola Menu</a>
    <a href="laporan.php" class="active">📋 Laporan</a>
    <a href="users.php">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">🚪 Keluar</a>
  </div>
</div>

<div class="content">
  <div class="page-title" style="display:flex;justify-content:space-between;align-items:center">
    <span>📋 Laporan Transaksi</span>
    <button class="btn-reset" onclick="document.getElementById('modalReset').classList.add('show')">🗑 Reset Transaksi</button>
  </div>

  <?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert alert-error"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="mode-tabs">
    <a href="?mode=hari&tgl=<?= $filter_tgl ?>" class="mode-tab <?= $mode==='hari'?'active':'' ?>">Per Hari</a>
    <a href="?mode=range&dari=<?= $filter_dari ?>&sampai=<?= $filter_sampai ?>" class="mode-tab <?= $mode==='range'?'active':'' ?>">Rentang Tanggal</a>
    <a href="?mode=tahun&tahun=<?= $filter_tahun ?>" class="mode-tab <?= $mode==='tahun'?'active':'' ?>">📅 Tahunan</a>
  </div>

  <form method="GET" class="filter-bar">
    <input type="hidden" name="mode" value="<?= $mode ?>">
    <?php if($mode==='hari'): ?>
    <div class="filter-group">
      <label>Tanggal</label>
      <input type="date" name="tgl" value="<?= $filter_tgl ?>">
    </div>
    <?php elseif($mode==='tahun'): ?>
    <div class="filter-group">
      <label>Tahun</label>
      <select name="tahun">
        <?php foreach($tahun_list as $t): ?>
        <option value="<?= $t ?>" <?= (int)$t===$filter_tahun?'selected':'' ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php else: ?>
    <div class="filter-group">
      <label>Dari</label>
      <input type="date" name="dari" value="<?= $filter_dari ?>">
    </div>
    <div class="filter-group">
      <label>Sampai</label>
      <input type="date" name="sampai" value="<?= $filter_sampai ?>">
    </div>
    <?php endif; ?>
    <button type="submit" class="btn-filter">Filter</button>
  </form>

  <div class="stats-row">
    <div class="stat-mini"><div class="label"><?= $mode==='tahun'?'Total Bulan Aktif':'Jumlah Transaksi' ?></div><div class="val"><?= $mode==='tahun' ? array_sum(array_map(fn($b)=>$b['jumlah_trx']>0?1:0,$omset_per_bulan)) : $total_trx ?></div></div>
    <div class="stat-mini"><div class="label">Total Omset <?= $mode==='tahun'?$filter_tahun:'' ?></div><div class="val" style="font-size:17px"><?= fmt($total_omset) ?></div></div>
    <div class="stat-mini"><div class="label">Rata-rata per Transaksi</div><div class="val" style="font-size:17px"><?= $total_trx ? fmt(round($total_omset/$total_trx)) : 'Rp 0' ?></div></div>
    <?php if($mode==='tahun'): ?>
    <div class="stat-mini"><div class="label">Total Transaksi <?= $filter_tahun ?></div><div class="val"><?= $total_trx ?></div></div>
    <?php endif; ?>
  </div>

  <?php if($mode==='tahun'): ?>
  <!-- TABEL TAHUNAN — omset per bulan -->
  <div class="card-box">
    <div style="padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.08);font-size:13px;font-weight:600;color:#f5c842">
      📅 Rekap Omset per Bulan — Tahun <?= $filter_tahun ?>
    </div>
    <table>
      <thead>
        <tr>
          <th>Bulan</th>
          <th>Transaksi</th>
          <th>Total Omset</th>
          <th class="hide-mobile">Rata-rata / Trx</th>
          <th class="hide-mobile">Grafik</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $max_omset = max(array_column($omset_per_bulan, 'omset')) ?: 1;
        $grand_total = 0;
        $grand_trx = 0;
        foreach ($omset_per_bulan as $bk => $b):
            $grand_total += $b['omset'];
            $grand_trx  += $b['jumlah_trx'];
            $bar_pct = round($b['omset'] / $max_omset * 100);
            $is_this_month = ($bk === date('m') && $filter_tahun == date('Y'));
        ?>
        <tr <?= $is_this_month ? 'style="background:rgba(245,200,66,0.06)"' : '' ?>>
          <td style="font-weight:600;color:<?= $b['omset']>0?'#fff':'rgba(255,255,255,0.3)' ?>">
            <?= $b['nama'] ?><?= $is_this_month?' <span style="font-size:10px;color:#f5c842">(bulan ini)</span>':'' ?>
          </td>
          <td style="color:<?= $b['jumlah_trx']>0?'rgba(255,255,255,0.8)':'rgba(255,255,255,0.25)' ?>">
            <?= $b['jumlah_trx'] > 0 ? $b['jumlah_trx'] . ' trx' : '—' ?>
          </td>
          <td style="font-weight:700;color:<?= $b['omset']>0?'#f5c842':'rgba(255,255,255,0.2)' ?>">
            <?= $b['omset'] > 0 ? fmt($b['omset']) : '—' ?>
          </td>
          <td class="hide-mobile" style="font-size:12px;color:rgba(255,255,255,0.4)">
            <?= ($b['jumlah_trx']>0) ? fmt(round($b['omset']/$b['jumlah_trx'])) : '—' ?>
          </td>
          <td class="hide-mobile" style="width:200px">
            <?php if($b['omset']>0): ?>
            <div style="background:rgba(255,255,255,0.07);border-radius:4px;height:10px;overflow:hidden">
              <div style="background:linear-gradient(90deg,#f5c842,#e8a020);height:100%;width:<?= $bar_pct ?>%;border-radius:4px"></div>
            </div>
            <?php else: ?>
            <div style="background:rgba(255,255,255,0.04);border-radius:4px;height:10px"></div>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <!-- Baris total -->
        <tr style="border-top:2px solid rgba(245,200,66,0.3);background:rgba(245,200,66,0.05)">
          <td style="font-weight:800;color:#f5c842">TOTAL <?= $filter_tahun ?></td>
          <td style="font-weight:700;color:#f5c842"><?= $grand_trx ?> trx</td>
          <td style="font-weight:800;color:#f5c842;font-size:15px"><?= fmt($grand_total) ?></td>
          <td class="hide-mobile" style="font-size:12px;color:rgba(255,255,255,0.5)"><?= $grand_trx>0 ? fmt(round($grand_total/$grand_trx)) : '—' ?></td>
          <td class="hide-mobile"></td>
        </tr>
      </tbody>
    </table>
  </div>

  <?php else: ?>
  <!-- TABEL TRANSAKSI DETAIL (per hari / rentang) -->
  <div class="card-box">
    <table class="trx-table">
      <thead>
        <tr>
          <th>Kode</th>
          <th>Item</th>
          <th>Total</th>
          <th>Metode</th>
          <th>Bayar</th>
          <th>Kembalian</th>
          <th>Kasir</th>
          <th>Waktu</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($list)): ?>
        <tr><td colspan="8" class="empty">Tidak ada transaksi</td></tr>
        <?php else: ?>
        <?php foreach($list as $t): ?>
        <?php $met = $t['metode'] ?? 'cash'; ?>
        <tr>
          <td class="trx-kode"><?= htmlspecialchars($t['kode']) ?></td>
          <td data-label="Item" style="font-size:11px;color:rgba(255,255,255,0.5)"><?= htmlspecialchars($t['items'] ?? '-') ?></td>
          <td data-label="Total" style="font-weight:700;color:#f5c842"><?= fmt($t['total']) ?></td>
          <td data-label="Metode"><?= $met==='qris'?'<span style="color:#80cfff">📱 QRIS</span>':'<span style="color:#80ff80">💵 Cash</span>' ?></td>
          <td data-label="Bayar"><?= fmt($t['bayar']) ?></td>
          <td data-label="Kembalian" style="color:#80ff80"><?= fmt($t['kembalian']) ?></td>
          <td data-label="Kasir"><?= htmlspecialchars($t['kasir']) ?></td>
          <td data-label="Waktu" style="font-size:11px;color:rgba(255,255,255,0.4)"><?= date('d/m/Y H:i', strtotime($t['waktu'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<!-- MODAL RESET -->
<div class="modal-overlay" id="modalReset">
  <div class="modal">
    <div class="modal-title">⚠️ Reset Transaksi</div>
    <div class="modal-desc">Data yang direset <strong>tidak bisa dikembalikan</strong>. Pilih jenis reset:</div>

    <div class="modal-tabs">
      <div class="modal-tab active" onclick="switchTab('hari')">Per Tanggal</div>
      <div class="modal-tab" onclick="switchTab('semua')">Semua Data</div>
    </div>

    <!-- Reset per hari -->
    <div class="modal-section show" id="tab-hari">
      <form method="POST" onsubmit="return konfirmasiReset('hari')">
        <input type="hidden" name="action" value="reset">
        <input type="hidden" name="tipe" value="hari">
        <label style="font-size:12px;color:rgba(255,255,255,0.4);display:block;margin-bottom:6px">Pilih Tanggal</label>
        <input type="date" name="tgl_reset" value="<?= date('Y-m-d') ?>" required>
        <div class="modal-actions">
          <button type="submit" class="btn-confirm-reset">Reset Tanggal Ini</button>
          <button type="button" class="btn-cancel" onclick="document.getElementById('modalReset').classList.remove('show')">Batal</button>
        </div>
      </form>
    </div>

    <!-- Reset semua -->
    <div class="modal-section" id="tab-semua">
      <form method="POST" onsubmit="return konfirmasiReset('semua')">
        <input type="hidden" name="action" value="reset">
        <input type="hidden" name="tipe" value="semua">
        <p style="font-size:13px;color:#ff7070;padding:12px;background:rgba(255,60,60,0.08);border-radius:8px;border:1px solid rgba(255,60,60,0.2)">
          ⚠️ Ini akan menghapus <strong>SEMUA</strong> riwayat transaksi dari semua waktu. Tidak bisa dibatalkan.
        </p>
        <div class="modal-actions">
          <button type="submit" class="btn-confirm-reset">Hapus Semua Transaksi</button>
          <button type="button" class="btn-cancel" onclick="document.getElementById('modalReset').classList.remove('show')">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleNav() { document.getElementById('mobileNav').classList.add('show'); }
function closeNav()  { document.getElementById('mobileNav').classList.remove('show'); }
function switchTab(tipe) {
  document.querySelectorAll('.modal-tab').forEach((t,i) => {
    t.classList.toggle('active', (tipe==='hari'&&i===0)||(tipe==='semua'&&i===1));
  });
  document.getElementById('tab-hari').classList.toggle('show', tipe==='hari');
  document.getElementById('tab-semua').classList.toggle('show', tipe==='semua');
}
function konfirmasiReset(tipe) {
  if (tipe === 'semua') {
    return confirm('⚠️ YAKIN ingin menghapus SEMUA data transaksi?\nTindakan ini tidak bisa dibatalkan!');
  }
  const tgl = document.querySelector('[name=tgl_reset]').value;
  return confirm('⚠️ Yakin ingin mereset transaksi tanggal ' + tgl + '?\nData tidak bisa dikembalikan.');
}
document.getElementById('modalReset').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('show');
});
</script>
</body>
</html>
