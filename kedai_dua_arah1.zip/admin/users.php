<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireAdmin();

$msg = '';
$err = '';

// TAMBAH USER
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='tambah') {
    $username = trim($_POST['username']??'');
    $password = $_POST['password']??'';
    $role     = $_POST['role']??'kasir';

    if (!$username || !$password) {
        $err = 'Username dan password wajib diisi.';
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE username=?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $err = 'Username sudah digunakan.';
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (username,password,role) VALUES (?,?,?)");
            $stmt->execute([$username, password_hash($password,PASSWORD_DEFAULT), $role]);
            $msg = "User \"$username\" berhasil ditambahkan.";
        }
    }
}

// GANTI PASSWORD
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='ganti_pass') {
    $id       = (int)($_POST['id']??0);
    $password = $_POST['password']??'';
    if ($id && strlen($password)>=4) {
        $stmt = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
        $stmt->execute([password_hash($password,PASSWORD_DEFAULT),$id]);
        $msg = 'Password berhasil diganti.';
    } else {
        $err = 'Password minimal 4 karakter.';
    }
}

// HAPUS USER
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='hapus') {
    $id = (int)($_POST['id']??0);
    if ($id && $id !== $_SESSION['user_id']) {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
        $msg = 'User berhasil dihapus.';
    } else {
        $err = 'Tidak bisa menghapus akun sendiri.';
    }
}

$users = $pdo->query("SELECT id,username,role FROM users ORDER BY role DESC,username")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users – Kedai Dua Arah</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; background:#0f0700; color:#fff; min-height:100vh; }
header { background:linear-gradient(135deg,#1f0d00,#3d1f00); border-bottom:1px solid rgba(245,200,66,0.2); padding:12px 20px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:100; }
.brand-name { font-size:17px; font-weight:700; color:#f5c842; }
.nav { display:flex; gap:4px; }
.nav a { color:rgba(255,255,255,0.5); text-decoration:none; padding:7px 12px; border-radius:7px; font-size:12px; transition:all 0.2s; white-space:nowrap; }
.nav a:hover, .nav a.active { background:rgba(245,200,66,0.15); color:#f5c842; }
.nav a.logout { color:rgba(255,100,100,0.6); }
.hamburger { display:none; flex-direction:column; gap:5px; cursor:pointer; padding:6px; border:1px solid rgba(255,255,255,0.15); border-radius:7px; background:none; }
.hamburger span { display:block; width:20px; height:2px; background:rgba(255,255,255,0.7); border-radius:2px; }
.mobile-nav { display:none; position:fixed; inset:0; z-index:200; }
.mobile-nav.show { display:block; }
.mobile-nav-backdrop { position:absolute; inset:0; background:rgba(0,0,0,0.6); }
.mobile-nav-drawer { position:absolute; right:0; top:0; bottom:0; width:220px; background:#1f0d00; border-left:1px solid rgba(245,200,66,0.2); display:flex; flex-direction:column; padding:16px 0; animation:slideIn 0.25s ease; }
@keyframes slideIn { from { transform:translateX(100%); } to { transform:translateX(0); } }
.mobile-nav-title { font-size:12px; color:rgba(255,255,255,0.3); padding:0 20px 12px; text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:8px; }
.mobile-nav-drawer a { display:block; padding:14px 20px; color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; border-left:3px solid transparent; }
.mobile-nav-drawer a:hover, .mobile-nav-drawer a.active { background:rgba(245,200,66,0.08); color:#f5c842; border-left-color:#f5c842; }
.mobile-nav-drawer a.logout { color:rgba(255,100,100,0.6); }
.content { padding:14px; max-width:800px; margin:0 auto; }
.page-title { font-size:18px; font-weight:700; color:#f5c842; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center; }
@media (max-width:640px) { .nav { display:none; } .hamburger { display:flex; } }
.alert { padding:10px 16px; border-radius:8px; font-size:13px; margin-bottom:16px; }
.alert-success { background:rgba(100,200,100,0.12); border:1px solid rgba(100,200,100,0.3); color:#80ff80; }
.alert-error { background:rgba(255,80,80,0.12); border:1px solid rgba(255,80,80,0.3); color:#ff8080; }
.card-box { background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:12px; overflow:hidden; margin-bottom:20px; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.1); color:rgba(255,255,255,0.4); font-size:11px; text-transform:uppercase; }
td { padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.05); }
.badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; }
.badge-gold { background:rgba(245,200,66,0.2); color:#f5c842; }
.badge-blue { background:rgba(80,120,255,0.15); color:#8899ff; }
.btn-sm { padding:5px 12px; border-radius:5px; font-size:12px; cursor:pointer; border:none; font-weight:600; }
.btn-primary { background:#f5c842; color:#1a0a00; }
.btn-danger { background:rgba(255,80,80,0.15); color:#ff8080; border:1px solid rgba(255,80,80,0.2); }
.btn-secondary { background:rgba(255,255,255,0.08); color:rgba(255,255,255,0.7); }

.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.7); display:none; align-items:center; justify-content:center; z-index:999; }
.modal-overlay.show { display:flex; }
.modal { background:#1a0d00; border:1px solid rgba(245,200,66,0.2); border-radius:16px; padding:28px; width:380px; }
.modal-title { font-size:16px; font-weight:700; color:#f5c842; margin-bottom:20px; }
.form-group { margin-bottom:14px; }
label { display:block; font-size:12px; color:rgba(255,255,255,0.5); margin-bottom:6px; text-transform:uppercase; }
input,select { width:100%; padding:10px 14px; background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:8px; color:white; font-size:14px; outline:none; }
input:focus,select:focus { border-color:#f5c842; }
select option { background:#1a0d00; }
.modal-actions { display:flex; gap:10px; margin-top:20px; }
.modal-actions .btn-sm { padding:10px 20px; font-size:14px; border-radius:8px; }
</style>
</head>
<body>
<header>
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:22px">☕</span>
    <div class="brand-name">Kedai Dua Arah</div>
  </div>
  <nav class="nav">
    <a href="index.php">📊 Dashboard</a>
    <a href="menu.php">🍜 Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php" class="active">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">Keluar</a>
  </nav>
  <button class="hamburger" onclick="toggleNav()"><span></span><span></span><span></span></button>
</header>
<div class="mobile-nav" id="mobileNav">
  <div class="mobile-nav-backdrop" onclick="closeNav()"></div>
  <div class="mobile-nav-drawer">
    <div class="mobile-nav-title">Menu Admin</div>
    <a href="index.php">📊 Dashboard</a>
    <a href="menu.php">🍜 Kelola Menu</a>
    <a href="laporan.php">📋 Laporan</a>
    <a href="users.php" class="active">👥 Users</a>
    <a href="/kedai_dua_arah/kasir/index.php">🛒 Kasir</a>
    <a href="/kedai_dua_arah/logout.php" class="logout">🚪 Keluar</a>
  </div>
</div>

<div class="content">
  <div class="page-title">
    👥 Kelola Users
    <button class="btn-sm btn-primary" onclick="document.getElementById('modalTambah').classList.add('show')">+ Tambah User</button>
  </div>

  <?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert alert-error"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="card-box">
    <table>
      <thead>
        <tr><th>Username</th><th>Role</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach($users as $u): ?>
        <tr>
          <td style="font-weight:600">
            <?= htmlspecialchars($u['username']) ?>
            <?php if($u['id']==$_SESSION['user_id']): ?>
            <span style="font-size:10px;color:rgba(255,255,255,0.3)">(kamu)</span>
            <?php endif; ?>
          </td>
          <td><span class="badge <?= $u['role']==='admin'?'badge-gold':'badge-blue' ?>"><?= $u['role'] ?></span></td>
          <td>
            <div style="display:flex;gap:6px">
              <button class="btn-sm btn-secondary" onclick="openGantiPass(<?= $u['id'] ?>,'<?= htmlspecialchars($u['username']) ?>')">Ganti Pass</button>
              <?php if($u['id']!=$_SESSION['user_id']): ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus user ini?')">
                <input type="hidden" name="action" value="hapus">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <button type="submit" class="btn-sm btn-danger">Hapus</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- MODAL TAMBAH -->
<div class="modal-overlay" id="modalTambah">
  <div class="modal">
    <div class="modal-title">➕ Tambah User</div>
    <form method="POST">
      <input type="hidden" name="action" value="tambah">
      <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
      <div class="form-group"><label>Password</label><input type="password" name="password" required minlength="4"></div>
      <div class="form-group">
        <label>Role</label>
        <select name="role">
          <option value="kasir">Kasir</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn-sm btn-primary">Simpan</button>
        <button type="button" class="btn-sm btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('show')">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL GANTI PASS -->
<div class="modal-overlay" id="modalGantiPass">
  <div class="modal">
    <div class="modal-title">🔑 Ganti Password</div>
    <p id="gpUsername" style="color:rgba(255,255,255,0.5);font-size:13px;margin-bottom:16px"></p>
    <form method="POST">
      <input type="hidden" name="action" value="ganti_pass">
      <input type="hidden" name="id" id="gp_id">
      <div class="form-group"><label>Password Baru</label><input type="password" name="password" required minlength="4"></div>
      <div class="modal-actions">
        <button type="submit" class="btn-sm btn-primary">Simpan</button>
        <button type="button" class="btn-sm btn-secondary" onclick="this.closest('.modal-overlay').classList.remove('show')">Batal</button>
      </div>
    </form>
  </div>
</div>

<script>
function toggleNav() { document.getElementById('mobileNav').classList.add('show'); }
function closeNav()  { document.getElementById('mobileNav').classList.remove('show'); }
function openGantiPass(id, username) {
  document.getElementById('gp_id').value = id;
  document.getElementById('gpUsername').textContent = 'User: ' + username;
  document.getElementById('modalGantiPass').classList.add('show');
}
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if(e.target===el) el.classList.remove('show'); });
});
</script>
</body>
</html>
