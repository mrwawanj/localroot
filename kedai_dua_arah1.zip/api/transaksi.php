<?php
// API: POST /api/transaksi.php — proses bayar
// API: GET /api/transaksi.php — riwayat transaksi (admin)
// API: GET /api/transaksi.php?mode=laporan&bulan=YYYY-MM — laporan bulanan
// API: GET /api/transaksi.php?mode=tahunan&tahun=YYYY — laporan tahunan

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/middleware.php';

$method = $_SERVER['REQUEST_METHOD'];
$mode   = $_GET['mode'] ?? '';

if ($method === 'POST') {
    $user = getAuthUser($pdo);
    $input = json_decode(file_get_contents('php://input'), true);

    $items    = $input['items'] ?? [];
    $total    = (int)($input['total'] ?? 0);
    $bayar    = (int)($input['bayar'] ?? $total);
    $kembalian = (int)($input['kembalian'] ?? 0);
    $metode   = in_array($input['metode'] ?? '', ['cash','qris']) ? $input['metode'] : 'cash';

    if (empty($items) || $total <= 0) {
        echo json_encode(['success'=>false,'message'=>'Data transaksi tidak valid']);
        exit;
    }

    $kode = 'TRX' . date('YmdHis') . rand(10,99);

    $pdo->beginTransaction();
    try {
        // Insert transaksi
        $stmt = $pdo->prepare("INSERT INTO transaksi (kode,total,bayar,kembalian,kasir,metode) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$kode, $total, $bayar, $kembalian, $user['username'], $metode]);
        $trxId = (int)$pdo->lastInsertId();

        // Insert detail + kurangi stok
        $stmtDetail = $pdo->prepare("INSERT INTO detail_transaksi (transaksi_id,menu_id,nama_menu,harga,qty,subtotal) VALUES (?,?,?,?,?,?)");
        $stmtStok   = $pdo->prepare("UPDATE menu SET stok = MAX(0, stok - ?) WHERE id = ?");

        foreach ($items as $item) {
            $menuId  = (int)($item['id'] ?? 0);
            $nama    = $item['nama'] ?? '';
            $harga   = (int)($item['harga'] ?? 0);
            $qty     = (int)($item['qty'] ?? 1);
            $subtotal = $harga * $qty;

            $stmtDetail->execute([$trxId, $menuId, $nama, $harga, $qty, $subtotal]);
            $stmtStok->execute([$qty, $menuId]);
        }

        $pdo->commit();
        echo json_encode([
            'success'   => true,
            'kode'      => $kode,
            'total'     => $total,
            'bayar'     => $bayar,
            'kembalian' => $kembalian,
            'metode'    => $metode,
            'waktu'     => date('Y-m-d H:i:s'),
            'kasir'     => $user['username']
        ]);

    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success'=>false,'message'=>'Gagal menyimpan transaksi: ' . $e->getMessage()]);
    }

} elseif ($method === 'GET') {
    $user = getAuthUser($pdo);

    if ($mode === 'laporan') {
        // Laporan bulanan — admin only
        requireAdmin($pdo);
        $bulan = $_GET['bulan'] ?? date('Y-m');

        $stmt = $pdo->prepare("
            SELECT t.kode, t.total, t.bayar, t.kembalian, t.kasir, t.metode,
                   t.waktu,
                   GROUP_CONCAT(d.nama_menu || ' x' || d.qty, ', ') as items
            FROM transaksi t
            LEFT JOIN detail_transaksi d ON d.transaksi_id = t.id
            WHERE strftime('%Y-%m', t.waktu) = ?
            GROUP BY t.id
            ORDER BY t.waktu DESC
        ");
        $stmt->execute([$bulan]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $totalOmset = array_sum(array_column($rows, 'total'));

        echo json_encode([
            'success' => true,
            'bulan'   => $bulan,
            'omset'   => (int)$totalOmset,
            'jumlah'  => count($rows),
            'data'    => $rows
        ]);

    } elseif ($mode === 'tahunan') {
        requireAdmin($pdo);
        $tahun = (int)($_GET['tahun'] ?? date('Y'));

        $stmt = $pdo->prepare("
            SELECT strftime('%m', waktu) as bulan,
                   COUNT(*) as jumlah_trx,
                   COALESCE(SUM(total), 0) as omset
            FROM transaksi
            WHERE strftime('%Y', waktu) = ?
            GROUP BY bulan ORDER BY bulan
        ");
        $stmt->execute([(string)$tahun]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Isi semua 12 bulan
        $bulanNames = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
        $result = [];
        for ($i = 1; $i <= 12; $i++) {
            $key = str_pad($i, 2, '0', STR_PAD_LEFT);
            $found = array_filter($rows, fn($r) => $r['bulan'] === $key);
            $found = array_values($found);
            $result[] = [
                'bulan'      => $bulanNames[$i-1],
                'bulan_num'  => $i,
                'jumlah_trx' => $found ? (int)$found[0]['jumlah_trx'] : 0,
                'omset'      => $found ? (int)$found[0]['omset'] : 0,
            ];
        }

        echo json_encode([
            'success' => true,
            'tahun'   => $tahun,
            'omset_total' => (int)array_sum(array_column($result, 'omset')),
            'data'    => $result
        ]);

    } else {
        // Riwayat transaksi hari ini (kasir bisa lihat milik sendiri)
        $today = date('Y-m-d');
        if ($user['role'] === 'admin') {
            $stmt = $pdo->prepare("SELECT kode, total, bayar, kembalian, kasir, metode, waktu FROM transaksi WHERE DATE(waktu) = ? ORDER BY waktu DESC LIMIT 50");
            $stmt->execute([$today]);
        } else {
            $stmt = $pdo->prepare("SELECT kode, total, bayar, kembalian, kasir, metode, waktu FROM transaksi WHERE DATE(waktu) = ? AND kasir = ? ORDER BY waktu DESC LIMIT 20");
            $stmt->execute([$today, $user['username']]);
        }

        echo json_encode(['success'=>true,'data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

} else {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Method not allowed']);
}
