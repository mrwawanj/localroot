<?php
// API: POST /api/auth.php
// Body: {"username":"...", "password":"..."}
// Returns: {"success":true, "token":"...", "role":"admin|kasir", "username":"..."}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'message'=>'Method not allowed']); exit; }

require_once __DIR__ . '/../includes/db.php';

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$password = $input['password'] ?? '';

if (!$username || !$password) {
    echo json_encode(['success'=>false,'message'=>'Username dan password wajib diisi']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['password'])) {
    echo json_encode(['success'=>false,'message'=>'Username atau password salah']);
    exit;
}

// Buat token sederhana: hash dari username+waktu+secret
$secret = 'kedai_dua_arah_secret_2024';
$token = hash('sha256', $user['id'] . $user['username'] . $user['role'] . $secret . date('Y-m-d'));

echo json_encode([
    'success'  => true,
    'token'    => $token,
    'role'     => $user['role'],
    'username' => $user['username'],
    'user_id'  => $user['id']
]);
