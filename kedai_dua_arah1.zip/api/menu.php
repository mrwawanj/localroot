<?php
// API: GET /api/menu.php — daftar menu aktif
// API: POST /api/menu.php — tambah menu (admin)
// API: PUT /api/menu.php?id=X — edit menu (admin)
// API: DELETE /api/menu.php?id=X — hapus menu (admin)

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/middleware.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if ($method === 'GET') {
    // Public — kasir dan admin bisa lihat
    getAuthUser($pdo);

    $kategori = $_GET['kategori'] ?? '';
    if ($kategori && $kategori !== 'Semua') {
        $stmt = $pdo->prepare("SELECT id, nama, kategori, harga, stok, foto FROM menu WHERE aktif = 1 AND kategori = ? ORDER BY kategori, nama");
        $stmt->execute([$kategori]);
    } else {
        $stmt = $pdo->query("SELECT id, nama, kategori, harga, stok, foto FROM menu WHERE aktif = 1 ORDER BY kategori, nama");
    }
    $menu = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Konversi tipe
    foreach ($menu as &$item) {
        $item['id']    = (int)$item['id'];
        $item['harga'] = (int)$item['harga'];
        $item['stok']  = (int)$item['stok'];
        // Foto: kembalikan URL lengkap kalau ada
        if ($item['foto']) {
            $item['foto_url'] = 'https://sumbar.desaangke138.asia/kedai_dua_arah/assets/foto/' . $item['foto'];
        } else {
            $item['foto_url'] = null;
        }
    }

    // Ambil daftar kategori unik
    $kategoriList = $pdo->query("SELECT DISTINCT kategori FROM menu WHERE aktif = 1 ORDER BY kategori")->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode([
        'success'   => true,
        'menu'      => $menu,
        'kategori'  => array_values($kategoriList)
    ]);

} elseif ($method === 'POST') {
    requireAdmin($pdo);
    $input = json_decode(file_get_contents('php://input'), true);

    $nama     = trim($input['nama'] ?? '');
    $kategori = trim($input['kategori'] ?? '');
    $harga    = (int)($input['harga'] ?? 0);
    $stok     = (int)($input['stok'] ?? 0);
    $foto     = trim($input['foto'] ?? '');

    if (!$nama || !$kategori || $harga <= 0) {
        echo json_encode(['success'=>false,'message'=>'Nama, kategori, dan harga wajib diisi']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO menu (nama, kategori, harga, stok, foto) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nama, $kategori, $harga, $stok, $foto]);

    echo json_encode(['success'=>true,'id'=>(int)$pdo->lastInsertId(),'message'=>'Menu berhasil ditambahkan']);

} elseif ($method === 'PUT') {
    requireAdmin($pdo);
    if (!$id) { echo json_encode(['success'=>false,'message'=>'ID diperlukan']); exit; }

    $input = json_decode(file_get_contents('php://input'), true);
    $nama     = trim($input['nama'] ?? '');
    $kategori = trim($input['kategori'] ?? '');
    $harga    = (int)($input['harga'] ?? 0);
    $stok     = (int)($input['stok'] ?? 0);
    $foto     = trim($input['foto'] ?? '');
    $aktif    = isset($input['aktif']) ? (int)$input['aktif'] : 1;

    $stmt = $pdo->prepare("UPDATE menu SET nama=?, kategori=?, harga=?, stok=?, foto=?, aktif=? WHERE id=?");
    $stmt->execute([$nama, $kategori, $harga, $stok, $foto, $aktif, $id]);

    echo json_encode(['success'=>true,'message'=>'Menu berhasil diupdate']);

} elseif ($method === 'DELETE') {
    requireAdmin($pdo);
    if (!$id) { echo json_encode(['success'=>false,'message'=>'ID diperlukan']); exit; }

    $pdo->prepare("UPDATE menu SET aktif = 0 WHERE id = ?")->execute([$id]);
    echo json_encode(['success'=>true,'message'=>'Menu berhasil dihapus']);

} else {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'Method not allowed']);
}
